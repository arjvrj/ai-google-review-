<?php
/**
 * card_home.php — Card panel dashboard
 * URL: card_home.php?slug=<slug>
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$page   = 'home';
$slug   = trim($_GET['slug'] ?? '');
$userId = (int)$_SESSION['user_id'];

/* ---------- Fetch + verify ownership ---------- */
$stmt = $conn->prepare("SELECT * FROM review_cards WHERE slug = ? AND user_id = ? LIMIT 1");
$stmt->execute([$slug, $userId]);
$card = $stmt->fetch();

if (!$card) {
    header('Location: dashboard.php');
    exit;
}

/* ---------- Stats ---------- */
$stmt = $conn->prepare("SELECT COUNT(*) FROM reviews WHERE card_id = ?");
$stmt->execute([$card['id']]);
$reviewCount = (int)$stmt->fetchColumn();

$stmt = $conn->prepare("SELECT AVG(rating) FROM reviews WHERE card_id = ?");
$stmt->execute([$card['id']]);
$avgRating = (float)($stmt->fetchColumn() ?? 0);

$stmt = $conn->prepare("SELECT COUNT(*) FROM reviews WHERE card_id = ? AND rating >= 4");
$stmt->execute([$card['id']]);
$highCount = (int)$stmt->fetchColumn();

$stmt = $conn->prepare("SELECT COUNT(*) FROM feedbacks WHERE card_id = ?");
$stmt->execute([$card['id']]);
$feedbackCount = (int)$stmt->fetchColumn();

$stmt = $conn->prepare("SELECT COUNT(*) FROM reviews WHERE card_id = ? AND details LIKE '%ai_generated%'");
$stmt->execute([$card['id']]);
$aiReviewCount = (int)$stmt->fetchColumn();

$reviewUrl = url('review.php?slug=' . urlencode($card['slug']));
$qrCodeUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($reviewUrl);

/* ---------- Trial days ---------- */
$trialDaysLeft = null;
if (!empty($card['expiry_date'])) {
    $trialDaysLeft = (int)ceil((strtotime($card['expiry_date']) - time()) / 86400);
}

ob_start();
?>

<!-- Welcome -->
<div class="mb-8">
    <h2 class="text-2xl font-bold text-gray-900">Welcome back, <?= htmlspecialchars($card['name']) ?>! 👋</h2>
    <p class="text-gray-600 mt-1">Here's what's happening with your review card.</p>
</div>

<!-- Trial alert -->
<?php if ($card['membership'] === 'trial' && !empty($card['expiry_date'])): ?>
    <div class="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6 rounded-r-lg">
        <div class="flex items-center flex-wrap gap-3">
            <div class="flex-shrink-0">
                <svg class="h-5 w-5 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9a1 1 0 00-1-1z" clip-rule="evenodd"/>
                </svg>
            </div>
            <div class="ml-3 flex-1 min-w-0">
                <p class="text-sm text-blue-700">
                    <span class="font-medium">Trial Period:</span>
                    Your trial expires on <?= date('M d, Y', strtotime($card['expiry_date'])) ?>
                    (<?= max(0, $trialDaysLeft) ?> days remaining)
                </p>
            </div>
            <a href="card_membership.php?slug=<?= urlencode($card['slug']) ?>"
               class="px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors">
                Upgrade Now
            </a>
        </div>
    </div>
<?php endif; ?>

<!-- Stats Grid -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center">
            <div class="p-2 bg-blue-100 rounded-lg">
                <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"/>
                </svg>
            </div>
            <div class="ml-4">
                <p class="text-sm font-medium text-gray-600">Total Reviews</p>
                <p class="text-2xl font-bold text-gray-900"><?= number_format($reviewCount) ?></p>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center">
            <div class="p-2 bg-yellow-100 rounded-lg">
                <svg class="w-6 h-6 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                </svg>
            </div>
            <div class="ml-4">
                <p class="text-sm font-medium text-gray-600">Average Rating</p>
                <p class="text-2xl font-bold <?= $avgRating >= 4 ? 'text-green-600' : ($avgRating >= 3 ? 'text-yellow-600' : 'text-red-600') ?>">
                    <?= number_format($avgRating, 1) ?>
                </p>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center">
            <div class="p-2 bg-purple-100 rounded-lg">
                <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
            <div class="ml-4">
                <p class="text-sm font-medium text-gray-600">AI Generated</p>
                <p class="text-2xl font-bold text-gray-900"><?= number_format($aiReviewCount) ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Review Link & QR -->
<div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-8">
    <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div class="flex-1 min-w-0">
            <h3 class="text-lg font-bold text-gray-900 mb-2">Your Review Page</h3>
            <p class="text-sm text-gray-500 mb-4">Share this link with your customers to collect reviews</p>

            <div class="flex items-center space-x-2 mb-4">
                <div class="flex-1 relative">
                    <input type="text" id="reviewUrl" value="<?= htmlspecialchars($reviewUrl) ?>" readonly
                           class="w-full px-4 py-3 pr-24 bg-gray-50 border border-gray-200 rounded-xl text-sm font-mono text-gray-700 focus:ring-2 focus:ring-blue-500">
                    <button onclick="copyReviewUrl()"
                            class="absolute right-2 top-1/2 transform -translate-y-1/2 px-4 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors">
                        <i class="fas fa-copy mr-1"></i> Copy
                    </button>
                </div>
            </div>

            <div class="flex flex-wrap gap-3">
                <a href="<?= htmlspecialchars($reviewUrl) ?>" target="_blank"
                   class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors text-sm">
                    <i class="fas fa-external-link-alt mr-2"></i> Open Page
                </a>
                <button onclick="downloadQRCode()"
                        class="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors text-sm">
                    <i class="fas fa-download mr-2"></i> Download QR
                </button>
                <button onclick="shareReviewPage()"
                        class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-xl hover:bg-gray-700 transition-colors text-sm">
                    <i class="fas fa-share-alt mr-2"></i> Share
                </button>
            </div>
        </div>

        <div class="flex-shrink-0">
            <div class="bg-gray-50 p-4 rounded-xl border border-gray-200">
                <img id="qrCodeImage" src="<?= htmlspecialchars($qrCodeUrl) ?>" alt="QR Code"
                     class="w-40 h-40 object-contain cursor-pointer hover:scale-105 transition-transform"
                     onclick="openQRModal()">
                <p class="text-xs text-gray-500 text-center mt-2">Click to enlarge</p>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-8">
    <h3 class="text-lg font-bold text-gray-900 mb-4">Quick Actions</h3>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">

        <a href="card_reviews.php?slug=<?= urlencode($card['slug']) ?>&filter=reviews"
           class="flex items-center p-4 bg-gray-50 rounded-xl hover:bg-blue-50 transition-colors group">
            <svg class="w-5 h-5 text-blue-600 mr-3 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/>
            </svg>
            <span class="text-sm font-medium text-gray-900">Manage Reviews</span>
        </a>

        <a href="card_reviews.php?slug=<?= urlencode($card['slug']) ?>&filter=feedback"
           class="flex items-center p-4 bg-gray-50 rounded-xl hover:bg-yellow-50 transition-colors group">
            <svg class="w-5 h-5 text-yellow-600 mr-3 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
            </svg>
            <span class="text-sm font-medium text-gray-900">
                Feedbacks
                <?php if ($feedbackCount > 0): ?>
                    <span class="bg-yellow-500 text-white text-xs px-2 py-0.5 rounded-full ml-1"><?= $feedbackCount ?></span>
                <?php endif; ?>
            </span>
        </a>

        <a href="card_settings.php?slug=<?= urlencode($card['slug']) ?>"
           class="flex items-center p-4 bg-gray-50 rounded-xl hover:bg-green-50 transition-colors group">
            <svg class="w-5 h-5 text-green-600 mr-3 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            <span class="text-sm font-medium text-gray-900">Card Settings</span>
        </a>

        <a href="<?= htmlspecialchars($reviewUrl) ?>" target="_blank"
           class="flex items-center p-4 bg-gray-50 rounded-xl hover:bg-purple-50 transition-colors group">
            <svg class="w-5 h-5 text-purple-600 mr-3 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
            </svg>
            <span class="text-sm font-medium text-gray-900">Preview Page</span>
        </a>
    </div>
</div>

<!-- QR Modal -->
<div id="qrModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-2xl max-w-md w-full p-6">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold text-gray-900">Your Review Page QR Code</h3>
            <button onclick="closeQRModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="text-center mb-4">
            <img id="qrModalImage" src="<?= htmlspecialchars($qrCodeUrl) ?>" alt="QR Code" class="w-64 h-64 mx-auto">
            <p class="text-sm text-gray-500 mt-3">Scan this QR code to leave a review</p>
        </div>
        <div class="text-center text-sm text-gray-600 bg-gray-50 rounded-lg p-3 mb-4">
            <p class="font-mono break-all"><?= htmlspecialchars($reviewUrl) ?></p>
        </div>
        <div class="flex space-x-3">
            <button onclick="downloadQRCode()"
                    class="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm font-medium">
                <i class="fas fa-download mr-2"></i> Download
            </button>
        </div>
    </div>
</div>

<!-- Toast -->
<div id="toast" class="fixed bottom-4 right-4 bg-gray-900 text-white px-6 py-3 rounded-xl shadow-lg z-50 hidden items-center">
    <i class="fas fa-check-circle text-green-400 mr-2"></i>
    <span id="toastMessage">Copied!</span>
</div>

<script>
function copyReviewUrl() {
    const urlInput = document.getElementById('reviewUrl');
    urlInput.select();
    urlInput.setSelectionRange(0, 99999);
    try { document.execCommand('copy'); } catch (e) {}
    if (navigator.clipboard) { navigator.clipboard.writeText(urlInput.value).catch(()=>{}); }
    showToast('Review page link copied!');
}

function showToast(message) {
    $('#toastMessage').text(message);
    $('#toast').removeClass('hidden').addClass('flex');
    setTimeout(() => $('#toast').addClass('hidden').removeClass('flex'), 2000);
}

function openQRModal() {
    $('#qrModal').removeClass('hidden').addClass('flex');
}

function closeQRModal() {
    $('#qrModal').addClass('hidden').removeClass('flex');
}

function downloadQRCode() {
    const qrImage = document.getElementById('qrCodeImage');
    const slug = '<?= htmlspecialchars($card['slug'], ENT_QUOTES) ?>';

    const canvas = document.createElement('canvas');
    canvas.width = qrImage.naturalWidth || 300;
    canvas.height = qrImage.naturalHeight || 300;
    const ctx = canvas.getContext('2d');

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = function() {
        ctx.drawImage(img, 0, 0);
        const dataURL = canvas.toDataURL('image/png');
        
        const a = document.createElement('a');
        a.href = dataURL;
        a.download = slug + '-qr-code.png';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        showToast('QR code downloaded!');
    };
    
    img.onerror = function() {
        showToast('Could not auto-download. Right-click the QR and save.');
    };

    img.src = qrImage.src;
}

function shareReviewPage() {
    const reviewUrl = '<?= htmlspecialchars($reviewUrl, ENT_QUOTES) ?>';
    const cardName  = '<?= htmlspecialchars($card['name'], ENT_QUOTES) ?>';
    if (navigator.share) {
        navigator.share({
            title: cardName + ' - Leave a Review',
            text: 'I would love your feedback! Please leave a review.',
            url: reviewUrl
        }).catch(() => {});
    } else {
        copyReviewUrl();
    }
}

$(document).keydown(function(e) { if (e.key === 'Escape') closeQRModal(); });
$('#qrModal').click(function(e) { if (e.target === this) closeQRModal(); });
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/includes/card_layout.php';