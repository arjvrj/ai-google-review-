<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$errors  = [];
$message = '';
$mode    = $_POST['mode'] ?? 'request'; // request | reset

$email       = trim($_POST['email'] ?? '');
$token       = trim($_POST['token'] ?? ($_GET['token'] ?? ''));
$newPass     = $_POST['password'] ?? '';
$newConfirm  = $_POST['password_confirm'] ?? '';

/* ---------- STEP 1: Request reset ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $mode === 'request') {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email.';
    } else {
        $isAdmin   = strcasecmp($email, getSetting('admin_email', '')) === 0;
        $user      = getUserByEmail($email);
        $resetToken = bin2hex(random_bytes(16));
        $expires    = date('Y-m-d H:i:s', time() + 3600); // 1 hour

        if ($isAdmin) {
            setSetting('admin_reset_token', $resetToken);
            setSetting('admin_reset_expires', $expires);
            $message = "Reset link generated for admin. <br><strong>Dev mode:</strong> <a class='text-purple-600 underline' href='forgot-password.php?token=" . urlencode($resetToken) . "'>Click here to reset</a>";
        } elseif ($user) {
            $stmt = $conn->prepare("UPDATE users SET otp = ? WHERE id = ?");
            $stmt->execute([$resetToken, $user['id']]);
            $message = "Reset link generated. <br><strong>Dev mode:</strong> <a class='text-purple-600 underline' href='forgot-password.php?token=" . urlencode($resetToken) . "'>Click here to reset</a>";
        } else {
            // Don't reveal whether the email exists
            $message = 'If that email is registered, a reset link has been generated.';
        }
    }
}

/* ---------- STEP 2: Perform reset ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $mode === 'reset') {
    if (strlen($newPass) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($newPass !== $newConfirm) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        $adminToken   = getSetting('admin_reset_token', '');
        $adminExpires = getSetting('admin_reset_expires', '');

        if ($adminToken && hash_equals($adminToken, $token) && strtotime($adminExpires) > time()) {
            // Admin reset
            setSetting('admin_password', password_hash($newPass, PASSWORD_DEFAULT));
            setSetting('admin_reset_token', '');
            setSetting('admin_reset_expires', '');
            $message = 'Admin password updated. <a href="login.php" class="text-purple-600 underline">Login now</a>';
        } else {
            // User reset
            $stmt = $conn->prepare("SELECT id FROM users WHERE otp = ? LIMIT 1");
            $stmt->execute([$token]);
            $u = $stmt->fetch();
            if ($u) {
                $upd = $conn->prepare("UPDATE users SET password = ?, otp = NULL WHERE id = ?");
                $upd->execute([password_hash($newPass, PASSWORD_DEFAULT), $u['id']]);
                $message = 'Password updated. <a href="login.php" class="text-purple-600 underline">Login now</a>';
            } else {
                $errors[] = 'Invalid or expired reset token.';
            }
        }
    }
}

$appName   = getSetting('app_name', 'ReviewAI');
$showReset = !empty($token);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password — <?= htmlspecialchars($appName) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center p-4">
<div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
    <div class="text-center mb-8">
        <div class="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-key text-3xl text-purple-600"></i>
        </div>
        <h1 class="text-2xl font-bold text-gray-900"><?= $showReset ? 'Set new password' : 'Forgot password' ?></h1>
        <p class="text-gray-500 text-sm mt-1">
            <?= $showReset ? 'Enter a new password below' : 'We\'ll send you a reset link' ?>
        </p>
    </div>

    <?php if ($errors): ?>
        <div class="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
            <?php foreach ($errors as $e): ?>
                <p class="text-red-700 text-sm"><i class="fas fa-exclamation-circle mr-1"></i> <?= htmlspecialchars($e) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if ($message): ?>
        <div class="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
            <p class="text-green-700 text-sm"><?= $message /* trusted: built from our own strings */ ?></p>
        </div>
    <?php endif; ?>

    <?php if ($showReset): ?>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="mode" value="reset">
            <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
            <div>
                <label class="text-xs font-medium text-gray-700 block mb-1">New Password</label>
                <input type="password" name="password" required minlength="6"
                    class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
            </div>
            <div>
                <label class="text-xs font-medium text-gray-700 block mb-1">Confirm Password</label>
                <input type="password" name="password_confirm" required minlength="6"
                    class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
            </div>
            <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl transition">
                Update Password <i class="fas fa-check ml-2"></i>
            </button>
        </form>
    <?php else: ?>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="mode" value="request">
            <div>
                <label class="text-xs font-medium text-gray-700 block mb-1">Email</label>
                <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                    class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
            </div>
            <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl transition">
                Send Reset Link <i class="fas fa-paper-plane ml-2"></i>
            </button>
        </form>

        <p class="text-center text-sm text-gray-500 mt-6">
            <a href="login.php" class="text-purple-600 font-medium hover:underline">Back to login</a>
        </p>
    <?php endif; ?>
</div>
</body>
</html>