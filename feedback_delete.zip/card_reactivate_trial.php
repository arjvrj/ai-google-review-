<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
requireLogin();

header('Content-Type: application/json');

$userId = (int)$_SESSION['user_id'];
$cardId = (int)($_POST['card_id'] ?? 0);

$stmt = $conn->prepare("SELECT id FROM review_cards WHERE id = ? AND user_id = ? LIMIT 1");
$stmt->execute([$cardId, $userId]);
if (!$stmt->fetch()) { echo json_encode(['error' => 'Card not found']); exit; }

$stmt = $conn->prepare("UPDATE review_cards SET membership = 'trial', expiry_date = DATE_ADD(NOW(), INTERVAL 3 DAY) WHERE id = ?");
$stmt->execute([$cardId]);

echo json_encode(['success' => true]);