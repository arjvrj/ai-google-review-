<?php
/**
 * Installation Wizard — Owner-first
 * Step 1: Welcome
 * Step 2: Database + App info (+ writes config.php with owner_email placeholder)
 * Step 3: Owner account (email + password) — also creates the first user row
 * Step 4: Done
 *
 * No .env, no .htaccess, no separate admin account.
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$configFile = __DIR__ . '/config.php';
$step   = (int)($_GET['step'] ?? 1);
$errors = [];

function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

function detectSiteUrl() {
    $https = false;
    if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') $https = true;
    elseif (($_SERVER['SERVER_PORT'] ?? '') == 443) $https = true;
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])
            && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') $https = true;

    $scheme = $https ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir    = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    $dir    = rtrim($dir, '/');
    if ($dir === '.' || $dir === '/') $dir = '';

    return $scheme . '://' . $host . $dir;
}

$autoSiteUrl = detectSiteUrl();

/* ---------- Redirect if already installed ---------- */
if (file_exists($configFile)) {
    $existing = include $configFile;
    if (!empty($existing['installed']) && in_array($step, [1, 2], true)) {
        $ownerExists = false;
        try {
            $pdo = new PDO(
                "mysql:host={$existing['db_host']};dbname={$existing['db_name']};charset=utf8mb4",
                $existing['db_user'], $existing['db_pass'],
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
            $stmt->execute([$existing['owner_email'] ?? '']);
            $ownerExists = (int)$stmt->fetchColumn() > 0;
        } catch (Exception $e) { $ownerExists = false; }

        header('Location: ' . ($ownerExists ? 'login.php' : 'install.php?step=3'));
        exit;
    }
}

/* ---------- STEP 2: DB + App info ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === 2) {
    $dbHost  = trim($_POST['db_host'] ?? 'localhost');
    $dbName  = trim($_POST['db_name'] ?? '');
    $dbUser  = trim($_POST['db_user'] ?? '');
    $dbPass  = $_POST['db_pass'] ?? '';
    $appName = trim($_POST['app_name'] ?? 'ReviewAI');
    $siteUrl = rtrim(trim($_POST['site_url'] ?? $autoSiteUrl), '/');

    if ($dbName === '' || $dbUser === '') $errors[] = 'Database name and user are required.';
    if ($appName === '') $appName = 'ReviewAI';
    if (!preg_match('#^https?://#i', $siteUrl)) $errors[] = 'Site URL must start with http:// or https://';

    if (empty($errors)) {
        try {
            $pdo = new PDO(
                "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
                $dbUser, $dbPass,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );

            $tables = [

                "users" => "CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    email VARCHAR(255) NOT NULL UNIQUE,
                    password VARCHAR(255) NOT NULL,
                    otp VARCHAR(255),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

                "review_cards" => "CREATE TABLE IF NOT EXISTS review_cards (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    name VARCHAR(255) NOT NULL,
                    slug VARCHAR(255) NOT NULL UNIQUE,
                    membership VARCHAR(50) DEFAULT 'trial',
                    expiry_date DATETIME DEFAULT NULL,
                    details JSON DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    INDEX idx_slug (slug)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

                "reviews" => "CREATE TABLE IF NOT EXISTS reviews (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    card_id INT NOT NULL,
                    customer_name VARCHAR(255) DEFAULT NULL,
                    rating INT NOT NULL,
                    body TEXT DEFAULT NULL,
                    details JSON DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_card_id (card_id),
                    INDEX idx_rating (rating),
                    FOREIGN KEY (card_id) REFERENCES review_cards(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

                "feedbacks" => "CREATE TABLE IF NOT EXISTS feedbacks (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    card_id INT NOT NULL,
                    customer_name VARCHAR(255) NOT NULL,
                    phone VARCHAR(20) NOT NULL,
                    email VARCHAR(255) NOT NULL,
                    message TEXT NOT NULL,
                    rating INT NOT NULL,
                    status ENUM('new','read','resolved') DEFAULT 'new',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_card_id (card_id),
                    INDEX idx_status (status),
                    FOREIGN KEY (card_id) REFERENCES review_cards(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

                "platform_settings" => "CREATE TABLE IF NOT EXISTS platform_settings (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    whatsapp VARCHAR(20) NOT NULL,
                    details JSON DEFAULT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

                "plans" => "CREATE TABLE IF NOT EXISTS plans (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    description TEXT,
                    price DECIMAL(10,2) NOT NULL,
                    sale_price DECIMAL(10,2) DEFAULT NULL,
                    features JSON,
                    cta VARCHAR(255),
                    duration INT DEFAULT 30,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

                "keywords" => "CREATE TABLE IF NOT EXISTS keywords (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    keyword VARCHAR(100) NOT NULL,
                    sort_order INT DEFAULT 0
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

                "settings" => "CREATE TABLE IF NOT EXISTS settings (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    setting_key VARCHAR(100) UNIQUE NOT NULL,
                    setting_value TEXT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            ];

            foreach ($tables as $name => $sql) {
                $pdo->exec($sql);
                $check = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($name));
                if (!$check->fetch()) throw new Exception("Failed to create table: {$name}");
            }

            // Seed default settings — owner_email will be filled in step 3
            $defaults = [
                'business_name'        => $appName,
                'business_description' => 'We provide excellent service!',
                'business_logo'        => '',
                'business_banner'      => '',
                'business_address'     => '',
                'business_phone'       => '',
                'business_whatsapp'    => '',
                'business_facebook'    => '',
                'business_instagram'   => '',
                'business_website'     => '',
                'google_review_url'    => 'https://www.google.com/search?q=review',
                'theme'                => 'purple',
                'custom_primary'       => '#7c3aed',
                'custom_gradient'      => 'linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%)',
                'enable_keywords'      => '1',
                'groq_api_key'         => '',
                'groq_model'           => 'llama-3.3-70b-versatile',
                'app_name'             => $appName,
                'site_url'             => $siteUrl,
                'owner_email'          => '',
                'installed'            => '1',
            ];
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            foreach ($defaults as $k => $v) {
                if ($k === 'owner_email') {
                    $chk = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'owner_email'");
                    $chk->execute();
                    if (trim((string)$chk->fetchColumn()) !== '') continue;
                }
                $stmt->execute([$k, $v]);
            }

            // Seed default keywords (only if none exist)
            $existingKw = (int)$pdo->query("SELECT COUNT(*) FROM keywords")->fetchColumn();
            if ($existingKw === 0) {
                $kwStmt = $pdo->prepare("INSERT INTO keywords (keyword, sort_order) VALUES (?, ?)");
                $kws = ['professional','quality','excellent service','friendly staff','clean','affordable','great value','highly recommend'];
                foreach ($kws as $i => $kw) $kwStmt->execute([$kw, $i]);
            }

            // Write config.php (owner_email filled in step 3 — placeholder for now)
            $configContent = "<?php\nreturn " . var_export([
                'db_host'     => $dbHost,
                'db_name'     => $dbName,
                'db_user'     => $dbUser,
                'db_pass'     => $dbPass,
                'site_url'    => $siteUrl,
                'app_name'    => $appName,
                'owner_email' => '',
                'installed'   => true,
            ], true) . ";\n";

            if (file_put_contents($configFile, $configContent) === false) {
                throw new Exception('Could not write config.php — check folder permissions.');
            }

            @mkdir(__DIR__ . '/assets/uploads', 0755, true);

            header('Location: install.php?step=3');
            exit;

        } catch (PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        } catch (Exception $e) {
            $errors[] = $e->getMessage();
        }
    }
}

/* ---------- STEP 3: Owner account (email + password) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === 3) {
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['password_confirm'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        if (!file_exists($configFile)) {
            $errors[] = 'config.php missing. Restart from step 2.';
        } else {
            $cfg = include $configFile;
            try {
                $pdo = new PDO(
                    "mysql:host={$cfg['db_host']};dbname={$cfg['db_name']};charset=utf8mb4",
                    $cfg['db_user'], $cfg['db_pass'],
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                );

                // If a user with this email already exists, refuse (prevents accidental overwrite)
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $errors[] = 'An account with that email already exists.';
                } else {
                    // 1) Insert the owner as a regular user
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $ins = $pdo->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
                    $ins->execute([$email, $hash]);

                    // 2) Store owner_email in settings
                    $upsert = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
                        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
                    $upsert->execute(['owner_email', $email]);

                    // 3) Rewrite config.php with owner_email filled in
                    $configContent = "<?php\nreturn " . var_export([
                        'db_host'     => $cfg['db_host'],
                        'db_name'     => $cfg['db_name'],
                        'db_user'     => $cfg['db_user'],
                        'db_pass'     => $cfg['db_pass'],
                        'site_url'    => $cfg['site_url'],
                        'app_name'    => $cfg['app_name'] ?? 'ReviewAI',
                        'owner_email' => $email,
                        'installed'   => true,
                    ], true) . ";\n";
                    @file_put_contents($configFile, $configContent);

                    header('Location: install.php?step=4');
                    exit;
                }
            } catch (Exception $e) {
                $errors[] = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

/* ---------- Step 3 pre-check: already have an owner? ---------- */
$ownerExists = false;
if ($step === 3 && file_exists($configFile)) {
    $cfg = include $configFile;
    if (!empty($cfg['installed'])) {
        try {
            $pdo = new PDO(
                "mysql:host={$cfg['db_host']};dbname={$cfg['db_name']};charset=utf8mb4",
                $cfg['db_user'], $cfg['db_pass'],
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            $email = $cfg['owner_email'] ?? '';
            if ($email !== '') {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $ownerExists = (bool)$stmt->fetch();
            }
        } catch (Exception $e) {}
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Install — <?= h($appName ?? 'ReviewAI') ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center p-4">
<div class="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-8">
    <div class="text-center mb-8">
        <div class="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-star text-3xl text-purple-600"></i>
        </div>
        <h1 class="text-2xl font-bold text-gray-900">Installation Wizard</h1>
        <p class="text-gray-500 text-sm mt-1">AI Google Review — Owner Edition</p>
    </div>

    <div class="flex items-center justify-center gap-2 mb-8">
        <?php for ($i = 1; $i <= 4; $i++): ?>
            <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold
                <?= $i <= $step ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-500' ?>"><?= $i ?></div>
            <?php if ($i < 4): ?><div class="w-8 h-1 <?= $i < $step ? 'bg-purple-600' : 'bg-gray-200' ?>"></div><?php endif; ?>
        <?php endfor; ?>
    </div>

    <?php if ($errors): ?>
        <div class="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
            <?php foreach ($errors as $e): ?>
                <p class="text-red-700 text-sm"><i class="fas fa-exclamation-circle mr-1"></i> <?= h($e) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if ($step === 1): ?>
        <div class="space-y-4">
            <h2 class="text-lg font-bold text-gray-900">Welcome!</h2>
            <p class="text-gray-600 text-sm">This wizard installs the AI Google Review system. You'll need:</p>
            <ul class="text-sm text-gray-600 space-y-2">
                <li><i class="fas fa-check text-green-500 mr-2"></i> MySQL database credentials</li>
                <li><i class="fas fa-check text-green-500 mr-2"></i> An app name</li>
                <li><i class="fas fa-check text-green-500 mr-2"></i> An owner email & password</li>
            </ul>
            <p class="text-xs text-gray-500 bg-blue-50 border border-blue-100 rounded-lg p-3">
                <i class="fas fa-info-circle text-blue-500 mr-1"></i>
                The owner email you provide grants access to <strong>owner.php</strong>. Other users sign up normally
                and land on their dashboard.
            </p>
            <a href="?step=2" class="block w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl text-center transition">
                Get Started <i class="fas fa-arrow-right ml-2"></i>
            </a>
        </div>

    <?php elseif ($step === 2): ?>
        <h2 class="text-lg font-bold text-gray-900 mb-4">Database & App Settings</h2>
        <form method="POST" class="space-y-4">
            <div class="grid grid-cols-2 gap-3">
                <div class="col-span-2">
                    <label class="text-xs font-medium text-gray-700 block mb-1">Database Host</label>
                    <input type="text" name="db_host" value="<?= h($_POST['db_host'] ?? 'localhost') ?>" required
                        class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                </div>
                <div>
                    <label class="text-xs font-medium text-gray-700 block mb-1">Database Name</label>
                    <input type="text" name="db_name" value="<?= h($_POST['db_name'] ?? '') ?>" required
                        class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                </div>
                <div>
                    <label class="text-xs font-medium text-gray-700 block mb-1">Database User</label>
                    <input type="text" name="db_user" value="<?= h($_POST['db_user'] ?? '') ?>" required
                        class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                </div>
                <div class="col-span-2">
                    <label class="text-xs font-medium text-gray-700 block mb-1">Database Password</label>
                    <input type="password" name="db_pass" value="<?= h($_POST['db_pass'] ?? '') ?>"
                        class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                </div>
                <div class="col-span-2">
                    <label class="text-xs font-medium text-gray-700 block mb-1">App Name</label>
                    <input type="text" name="app_name" value="<?= h($_POST['app_name'] ?? 'ReviewAI') ?>" required
                        class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                </div>
                <div class="col-span-2">
                    <label class="text-xs font-medium text-gray-700 block mb-1">Site URL</label>
                    <input type="text" name="site_url" value="<?= h($_POST['site_url'] ?? $autoSiteUrl) ?>" required
                        class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none font-mono text-xs">
                    <p class="text-[11px] text-gray-500 mt-1">Auto-detected. Edit if behind a proxy/CDN.</p>
                </div>
            </div>

            <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl transition">
                Install <i class="fas fa-database ml-2"></i>
            </button>
        </form>

    <?php elseif ($step === 3): ?>
        <?php if ($ownerExists): ?>
            <div class="text-center space-y-4">
                <h2 class="text-lg font-bold">Owner already exists</h2>
                <a href="login.php" class="block w-full bg-purple-600 text-white font-semibold py-3 rounded-xl text-center">Go to Login</a>
            </div>
        <?php else: ?>
            <h2 class="text-lg font-bold text-gray-900 mb-1">Create Owner Account</h2>
            <p class="text-xs text-gray-500 mb-4">
                This email will have full access to the Owner Panel. Other users sign up normally.
            </p>
            <form method="POST" class="space-y-4">
                <div>
                    <label class="text-xs font-medium text-gray-700 block mb-1">Email</label>
                    <input type="email" name="email" required value="<?= h($_POST['email'] ?? '') ?>"
                        class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                </div>
                <div>
                    <label class="text-xs font-medium text-gray-700 block mb-1">Password (min 6)</label>
                    <input type="password" name="password" required minlength="6"
                        class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                </div>
                <div>
                    <label class="text-xs font-medium text-gray-700 block mb-1">Confirm Password</label>
                    <input type="password" name="password_confirm" required minlength="6"
                        class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                </div>
                <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl transition">
                    Create Owner Account <i class="fas fa-crown ml-2"></i>
                </button>
            </form>
        <?php endif; ?>

    <?php elseif ($step === 4): ?>
        <div class="text-center space-y-4">
            <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <i class="fas fa-check text-4xl text-green-600"></i>
            </div>
            <h2 class="text-xl font-bold text-gray-900">Installation Complete!</h2>
            <p class="text-gray-600 text-sm">Your AI Google Review system is ready.</p>
            <div class="bg-blue-50 border border-blue-100 rounded-xl p-3 text-xs text-blue-800 text-left">
                <i class="fas fa-lightbulb mr-1"></i>
                <strong>Next:</strong> Log in with your owner email. Add your <strong>GROQ API key</strong> later in
                <em>Owner Panel → Settings</em>.
            </div>
            <a href="index.php" class="block w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl transition">
                Go to Homepage <i class="fas fa-arrow-right ml-2"></i>
            </a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>