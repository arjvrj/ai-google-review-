<?php
/**
 * signup.php — Register a new regular user
 * On success: logs the user in and redirects to list.php
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

/* Redirect already-logged-in users */
if (isLoggedIn()) {
    header('Location: ' . (isOwner() ? 'owner.php' : 'list.php'));
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['password_confirm'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email.';
    if (strlen($password) < 6)                      $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm)                     $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            $errors[] = 'An account with that email already exists.';
        } else {
            try {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
                $stmt->execute([$email, $hash]);
                $userId = (int)$conn->lastInsertId();

                /* Log the new user in */
                loginUser($userId, $email);

                /* Owner email? → owner panel. Otherwise → their cards list */
                if (isOwnerEmail($email)) {
                    header('Location: owner.php');
                } else {
                    header('Location: list.php');
                }
                exit;

            } catch (Exception $e) {
                $errors[] = 'Signup failed: ' . $e->getMessage();
            }
        }
    }
}

$appName = getSetting('app_name', 'ReviewAI');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign Up — <?= htmlspecialchars($appName) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center p-4">
<div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
    <div class="text-center mb-8">
        <div class="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-star text-3xl text-purple-600"></i>
        </div>
        <h1 class="text-2xl font-bold text-gray-900">Create your account</h1>
        <p class="text-gray-500 text-sm mt-1">Start collecting AI-powered reviews</p>
    </div>

    <?php if ($errors): ?>
        <div class="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
            <?php foreach ($errors as $e): ?>
                <p class="text-red-700 text-sm"><i class="fas fa-exclamation-circle mr-1"></i> <?= htmlspecialchars($e) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
        <div>
            <label class="text-xs font-medium text-gray-700 block mb-1">Email</label>
            <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
        </div>
        <div>
            <label class="text-xs font-medium text-gray-700 block mb-1">Password</label>
            <input type="password" name="password" required minlength="6"
                class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
        </div>
        <div>
            <label class="text-xs font-medium text-gray-700 block mb-1">Confirm Password</label>
            <input type="password" name="password_confirm" required minlength="6"
                class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
        </div>
        <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl transition">
            Sign Up <i class="fas fa-user-plus ml-2"></i>
        </button>
    </form>

    <p class="text-center text-sm text-gray-500 mt-6">
        Already have an account?
        <a href="login.php" class="text-purple-600 font-medium hover:underline">Log in</a>
    </p>
</div>
</body>
</html>