<?php
/**
 * owner_cards.php — Owner panel: manage all review cards
 * URL:   owner_cards.php?search=...&membership=...&page=N
 * POST:  owner_cards.php?action=update_membership
 *        owner_cards.php?action=delete
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireOwner();

/* =========================================================
   HELPER: membership badge/color classes
   ========================================================= */
function membershipBadge(string $m): string {
    switch (strtolower($m)) {
        case 'trial':      return 'bg-yellow-100 text-yellow-800';
        case 'pro':        return 'bg-blue-100 text-blue-800';
        case 'enterprise': return 'bg-purple-100 text-purple-800';
        case 'premium':    return 'bg-indigo-100 text-indigo-800';
        case 'basic':      return 'bg-green-100 text-green-800';
        case 'expired':    return 'bg-red-100 text-red-800';
        default:           return 'bg-gray-100 text-gray-800';
    }
}
function membershipColor(string $m): string {
    switch (strtolower($m)) {
        case 'trial':      return 'text-yellow-600';
        case 'pro':        return 'text-blue-600';
        case 'enterprise': return 'text-purple-600';
        case 'premium':    return 'text-indigo-600';
        case 'basic':      return 'text-green-600';
        case 'expired':    return 'text-red-600';
        default:           return 'text-gray-600';
    }
}

/* =========================================================
   AJAX DISPATCHER (runs before any HTML output)
   ========================================================= */
$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'update_membership' || $action === 'delete') {
    header('Content-Type: application/json');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }

    /* ---------- UPDATE MEMBERSHIP ---------- */
    if ($action === 'update_membership') {
        $cardId     = (int)($_POST['card_id'] ?? 0);
        $membership = trim($_POST['membership'] ?? '');
        $expiry     = trim($_POST['expiry_date'] ?? '');

        if ($cardId <= 0 || $membership === '' || $expiry === '') {
            echo json_encode(['error' => 'Missing required fields']);
            exit;
        }

        /* Normalize datetime-local input (2025-01-01T12:00) → MySQL DATETIME */
        $expiry = str_replace('T', ' ', $expiry);
        if (strlen($expiry) === 16) $expiry .= ':00';

        try {
            $stmt = $conn->prepare("UPDATE review_cards SET membership = ?, expiry_date = ? WHERE id = ?");
            $stmt->execute([$membership, $expiry, $cardId]);

            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            echo json_encode(['error' => 'Could not update membership']);
        }
        exit;
    }

    /* ---------- DELETE CARD ---------- */
    if ($action === 'delete') {
        $cardId = (int)($_POST['id'] ?? 0);
        if ($cardId <= 0) {
            echo json_encode(['error' => 'Invalid card']);
            exit;
        }

        try {
            // FK ON DELETE CASCADE handles reviews + feedbacks
            $stmt = $conn->prepare("DELETE FROM review_cards WHERE id = ?");
            $stmt->execute([$cardId]);

            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            echo json_encode(['error' => 'Could not delete card']);
        }
        exit;
    }
}

/* =========================================================
   RENDER
   ========================================================= */

$page             = 'cards';
$search           = trim($_GET['search'] ?? '');
$membershipFilter = trim($_GET['membership'] ?? '');
$pageNum          = max(1, (int)($_GET['page'] ?? 1));
$perPage          = 20;
$offset           = ($pageNum - 1) * $perPage;

$where  = [];
$params = [];

if ($search !== '') {
    $where[]  = "(rc.name LIKE ? OR rc.slug LIKE ? OR u.email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($membershipFilter !== '') {
    $where[]  = "rc.membership = ?";
    $params[] = $membershipFilter;
}
$whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

/* Total */
$stmt = $conn->prepare("SELECT COUNT(*) FROM review_cards rc JOIN users u ON rc.user_id = u.id $whereClause");
$stmt->execute($params);
$totalCards = (int)$stmt->fetchColumn();
$totalPages = (int)ceil($totalCards / $perPage);

/* Cards with stats */
$stmt = $conn->prepare("
    SELECT rc.*, u.email AS user_email, u.id AS user_id,
           COUNT(DISTINCT r.id) AS review_count,
           COUNT(DISTINCT f.id) AS feedback_count,
           AVG(r.rating)        AS avg_rating
    FROM review_cards rc
    JOIN users u ON rc.user_id = u.id
    LEFT JOIN reviews r ON rc.id = r.card_id
    LEFT JOIN feedbacks f ON rc.id = f.card_id
    $whereClause
    GROUP BY rc.id
    ORDER BY rc.created_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$cards = $stmt->fetchAll();

/* Plans for modal */
$plans = $conn->query("SELECT * FROM plans ORDER BY price ASC")->fetchAll();

/* Membership counts */
$membershipCounts = $conn->query("SELECT membership, COUNT(*) AS count FROM review_cards GROUP BY membership")->fetchAll();
$membershipData = [];
foreach ($membershipCounts as $mc) $membershipData[$mc['membership']] = (int)$mc['count'];

/* Membership types for filter */
$membershipTypes = $conn->query("SELECT DISTINCT membership FROM review_cards ORDER BY membership")->fetchAll();

ob_start();
?>

<div class="mb-6 flex justify-between items-center">
    <div>
        <h2 class="text-2xl font-bold text-gray-900">Review Cards</h2>
        <p class="text-gray-500 mt-1">Manage all review cards and memberships</p>
    </div>
</div>

<!-- Stats -->
<div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <p class="text-sm text-gray-600">Total Cards</p>
        <p class="text-2xl font-bold text-gray-900"><?= number_format($totalCards) ?></p>
    </div>
    <?php $i = 0; foreach ($membershipData as $type => $count): $i++; ?>
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <p class="text-sm text-gray-600"><?= htmlspecialchars(ucfirst($type)) ?></p>
            <p class="text-2xl font-bold <?= membershipColor($type) ?>"><?= number_format($count) ?></p>
        </div>
    <?php endforeach; ?>
    <?php for (; $i < 3; $i++): ?>
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <p class="text-sm text-gray-600">-</p>
            <p class="text-2xl font-bold text-gray-300">0</p>
        </div>
    <?php endfor; ?>
</div>

<!-- Filters -->
<div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-6">
    <form method="GET" class="flex gap-4 flex-wrap">
        <div class="flex-1 min-w-[200px] relative">
            <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                   placeholder="Search by name, slug or email..."
                   class="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
        </div>
        <select name="membership" class="px-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
            <option value="">All Memberships</option>
            <?php foreach ($membershipTypes as $mt): ?>
                <option value="<?= htmlspecialchars($mt['membership']) ?>" <?= $membershipFilter === $mt['membership'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars(ucfirst($mt['membership'])) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm hover:bg-purple-700 transition-colors">
            <i class="fas fa-filter mr-1"></i> Filter
        </button>
        <?php if ($search || $membershipFilter): ?>
            <a href="owner_cards.php" class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm hover:bg-gray-50 transition-colors">
                <i class="fas fa-times mr-1"></i> Clear
            </a>
        <?php endif; ?>
    </form>
</div>

<!-- Table -->
<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Card</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Owner</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Membership</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Expiry</th>
                    <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 bg-white">
                <?php if (empty($cards)): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center text-gray-500">
                            <i class="fas fa-folder-open text-4xl text-gray-300 mb-3 block"></i>
                            <p>No review cards found</p>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($cards as $c): ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-6 py-4">
                                <p class="text-sm font-medium text-gray-900"><?= htmlspecialchars($c['name']) ?></p>
                                <p class="text-xs text-gray-500 font-mono">review.php?slug=<?= htmlspecialchars($c['slug']) ?></p>
                            </td>
                            <td class="px-6 py-4">
                                <p class="text-sm text-gray-900"><?= htmlspecialchars($c['user_email']) ?></p>
                                <p class="text-xs text-gray-500">ID: #<?= (int)$c['user_id'] ?></p>
                            </td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 text-xs font-medium rounded-full <?= membershipBadge($c['membership']) ?>">
                                    <?= htmlspecialchars(ucfirst($c['membership'])) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <?php if (!empty($c['expiry_date'])): ?>
                                    <?php $isExpired = strtotime($c['expiry_date']) < time(); ?>
                                    <p class="text-sm <?= $isExpired ? 'text-red-600 font-medium' : 'text-gray-600' ?>">
                                        <?= date('M d, Y', strtotime($c['expiry_date'])) ?>
                                    </p>
                                    <?php if ($isExpired): ?>
                                        <span class="text-xs text-red-500 font-medium">Expired</span>
                                    <?php else: ?>
                                        <?php $daysLeft = (int)ceil((strtotime($c['expiry_date']) - time()) / 86400); ?>
                                        <span class="text-xs text-green-500"><?= $daysLeft ?> days left</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-sm text-gray-400">Not set</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex justify-center space-x-2">
                                    <a href="review.php?slug=<?= urlencode($c['slug']) ?>" target="_blank"
                                       class="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="View Page">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <button onclick='openMembershipModal(<?= (int)$c['id'] ?>, <?= json_encode($c['name']) ?>, <?= json_encode($c['membership']) ?>, <?= json_encode($c['expiry_date']) ?>)'
                                            class="p-2 text-purple-600 hover:bg-purple-50 rounded-lg transition-colors" title="Change Membership">
                                        <i class="fas fa-crown"></i>
                                    </button>
                                    <button onclick='deleteCard(<?= (int)$c['id'] ?>, <?= json_encode($c['name']) ?>)'
                                            class="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Delete Card">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Pagination -->
<?php if ($totalPages > 1): ?>
    <div class="flex justify-between items-center mt-6 flex-wrap gap-3">
        <p class="text-sm text-gray-500">
            Showing <?= $offset + 1 ?> - <?= min($offset + $perPage, $totalCards) ?> of <?= $totalCards ?> cards
        </p>
        <div class="flex space-x-2 flex-wrap">
            <?php if ($pageNum > 1): ?>
                <a href="?page=<?= $pageNum - 1 ?>&search=<?= urlencode($search) ?>&membership=<?= urlencode($membershipFilter) ?>"
                   class="px-4 py-2 rounded-lg text-sm bg-white text-gray-700 hover:bg-gray-50 border border-gray-200">
                    <i class="fas fa-chevron-left mr-1"></i> Previous
                </a>
            <?php endif; ?>

            <?php $start = max(1, $pageNum - 2); $end = min($totalPages, $pageNum + 2); ?>

            <?php if ($start > 1): ?>
                <a href="?page=1&search=<?= urlencode($search) ?>&membership=<?= urlencode($membershipFilter) ?>"
                   class="px-4 py-2 rounded-lg text-sm bg-white text-gray-700 hover:bg-gray-50 border border-gray-200">1</a>
                <?php if ($start > 2): ?><span class="px-2 py-2 text-gray-400">...</span><?php endif; ?>
            <?php endif; ?>

            <?php for ($i = $start; $i <= $end; $i++): ?>
                <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&membership=<?= urlencode($membershipFilter) ?>"
                   class="px-4 py-2 rounded-lg text-sm transition-colors <?= $i == $pageNum ? 'bg-purple-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>

            <?php if ($end < $totalPages): ?>
                <?php if ($end < $totalPages - 1): ?><span class="px-2 py-2 text-gray-400">...</span><?php endif; ?>
                <a href="?page=<?= $totalPages ?>&search=<?= urlencode($search) ?>&membership=<?= urlencode($membershipFilter) ?>"
                   class="px-4 py-2 rounded-lg text-sm bg-white text-gray-700 hover:bg-gray-50 border border-gray-200"><?= $totalPages ?></a>
            <?php endif; ?>

            <?php if ($pageNum < $totalPages): ?>
                <a href="?page=<?= $pageNum + 1 ?>&search=<?= urlencode($search) ?>&membership=<?= urlencode($membershipFilter) ?>"
                   class="px-4 py-2 rounded-lg text-sm bg-white text-gray-700 hover:bg-gray-50 border border-gray-200">
                    Next <i class="fas fa-chevron-right ml-1"></i>
                </a>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<!-- Membership Modal -->
<div id="membershipModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-2xl max-w-md w-full p-6">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold">Change Membership</h3>
            <button onclick="closeMembershipModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <p class="text-gray-600 mb-4">Card: <span id="membershipCardName" class="font-bold"></span></p>

        <form id="membershipForm" onsubmit="updateMembership(event)">
            <input type="hidden" id="membershipCardId" name="card_id">

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Current Membership</label>
                <span id="currentMembership" class="px-3 py-1 bg-gray-100 rounded-full text-sm font-medium"></span>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Select Plan *</label>
                <select id="planSelect" name="plan_id" required
                        class="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
                    <option value="">Choose a plan...</option>
                    <?php foreach ($plans as $plan): ?>
                        <option value="<?= (int)$plan['id'] ?>"
                                data-duration="<?= (int)$plan['duration'] ?>"
                                data-name="<?= htmlspecialchars($plan['name']) ?>">
                            <?= htmlspecialchars($plan['name']) ?> - ₹<?= number_format($plan['sale_price'] ?? $plan['price']) ?> (<?= (int)$plan['duration'] ?> days)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Membership Type</label>
                <input type="text" id="membershipType" name="membership" required
                       class="w-full px-3 py-2 border border-gray-200 rounded-lg bg-gray-50"
                       placeholder="e.g., trial, pro, enterprise">
                <p class="text-xs text-gray-500 mt-1">Auto-filled from plan name</p>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Expiry Date</label>
                <input type="datetime-local" id="expiryDate" name="expiry_date" required
                       class="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
            </div>

            <div class="flex space-x-3">
                <button type="button" onclick="closeMembershipModal()"
                        class="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">Cancel</button>
                <button type="submit"
                        class="flex-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-medium">
                    <i class="fas fa-crown mr-2"></i> Update
                </button>
            </div>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
function openMembershipModal(cardId, cardName, currentMembership, currentExpiry) {
    $('#membershipCardId').val(cardId);
    $('#membershipCardName').text(cardName);
    $('#currentMembership').text(currentMembership.charAt(0).toUpperCase() + currentMembership.slice(1));
    $('#membershipType').val(currentMembership);

    if (currentExpiry && currentExpiry !== 'null' && currentExpiry !== '') {
        const expiry = new Date(currentExpiry.replace(' ', 'T'));
        $('#expiryDate').val(expiry.toISOString().slice(0, 16));
    } else {
        const d = new Date();
        d.setDate(d.getDate() + 30);
        $('#expiryDate').val(d.toISOString().slice(0, 16));
    }

    $('#planSelect').val('');
    $('#membershipModal').removeClass('hidden').addClass('flex');
}

function closeMembershipModal() {
    $('#membershipModal').removeClass('flex').addClass('hidden');
}

$('#planSelect').on('change', function() {
    const opt      = $(this).find('option:selected');
    const planName = opt.data('name');
    const duration = parseInt(opt.data('duration')) || 0;

    if (planName && duration > 0) {
        const nl = String(planName).toLowerCase();
        let type = nl;
        if (nl.includes('trial'))       type = 'trial';
        else if (nl.includes('enterprise')) type = 'enterprise';
        else if (nl.includes('pro'))    type = 'pro';

        $('#membershipType').val(type);

        const d = new Date();
        d.setDate(d.getDate() + duration);
        $('#expiryDate').val(d.toISOString().slice(0, 16));
    }
});

function updateMembership(e) {
    e.preventDefault();

    const formData   = new FormData(e.target);
    const submitBtn  = $(e.target).find('button[type="submit"]');
    const originalHtml = submitBtn.html();

    submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin mr-2"></i> Updating...');

    $.ajax({
        url: 'owner_cards.php?action=update_membership',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function(res) {
            if (res.success) {
                location.reload();
            } else {
                alert('Error: ' + (res.error || 'Unknown error'));
                submitBtn.prop('disabled', false).html(originalHtml);
            }
        },
        error: function() {
            alert('Error updating membership.');
            submitBtn.prop('disabled', false).html(originalHtml);
        }
    });
}

function deleteCard(id, name) {
    if (!confirm(`Delete "${name}"? This cannot be undone and will delete all associated reviews and feedbacks.`)) return;
    if (!confirm('Please confirm again. This will permanently delete all data.')) return;

    $.ajax({
        url: 'owner_cards.php?action=delete',
        method: 'POST',
        data: { id: id },
        dataType: 'json',
        success: function(res) {
            if (res.success) location.reload();
            else alert('Error: ' + (res.error || 'Unknown error'));
        },
        error: function() {
            alert('Error deleting card.');
        }
    });
}

$(document).keydown(function(e) { if (e.key === 'Escape') closeMembershipModal(); });
$('#membershipModal').click(function(e) { if (e.target === this) closeMembershipModal(); });
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/includes/owner_layout.php';