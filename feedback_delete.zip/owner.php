<?php
/**
 * owner.php — Owner Panel dashboard
 * Loaded directly (no rewrites). Requires owner session.
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

if (!isOwner()) {
    header('Location: login.php');
    exit;
}

$page = 'home';

/* ---------- Stats ---------- */
$totalUsers     = (int)$conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalCards     = (int)$conn->query("SELECT COUNT(*) FROM review_cards")->fetchColumn();
$totalReviews   = (int)$conn->query("SELECT COUNT(*) FROM reviews")->fetchColumn();
$totalFeedbacks = (int)$conn->query("SELECT COUNT(*) FROM feedbacks")->fetchColumn();

$avgRating   = (float)($conn->query("SELECT AVG(rating) FROM reviews")->fetchColumn() ?? 0);
$highRatings = (int)$conn->query("SELECT COUNT(*) FROM reviews WHERE rating >= 4")->fetchColumn();

$membershipStats = $conn->query("
    SELECT membership, COUNT(*) AS count
    FROM review_cards
    GROUP BY membership
")->fetchAll();

/* ---------- Recent activity ---------- */
$recentUsers = $conn->query("
    SELECT id, email, created_at
    FROM users
    ORDER BY created_at DESC
    LIMIT 5
")->fetchAll();

$recentCards = $conn->query("
    SELECT rc.*, u.email AS user_email
    FROM review_cards rc
    JOIN users u ON rc.user_id = u.id
    ORDER BY rc.created_at DESC
    LIMIT 5
")->fetchAll();

$recentReviews = $conn->query("
    SELECT r.*, rc.name AS card_name, rc.slug
    FROM reviews r
    JOIN review_cards rc ON r.card_id = rc.id
    ORDER BY r.created_at DESC
    LIMIT 5
")->fetchAll();

$recentFeedbacks = $conn->query("
    SELECT f.*, rc.name AS card_name
    FROM feedbacks f
    JOIN review_cards rc ON f.card_id = rc.id
    ORDER BY f.created_at DESC
    LIMIT 5
")->fetchAll();

$ratingDistribution = $conn->query("
    SELECT rating, COUNT(*) AS count
    FROM reviews
    GROUP BY rating
    ORDER BY rating DESC
")->fetchAll();

/* ---------- Render view ---------- */
ob_start();
?>

<div class="mb-8">
    <h2 class="text-2xl font-bold text-gray-900">Owner Dashboard</h2>
    <p class="text-gray-500 mt-1">Overview of your review platform</p>
</div>

<!-- Top Stats -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-600">Total Users</p>
                <p class="text-3xl font-bold text-gray-900 mt-1"><?= number_format($totalUsers) ?></p>
            </div>
            <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <i class="fas fa-users text-blue-600 text-xl"></i>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-600">Review Cards</p>
                <p class="text-3xl font-bold text-gray-900 mt-1"><?= number_format($totalCards) ?></p>
            </div>
            <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <i class="fas fa-id-card text-purple-600 text-xl"></i>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-600">Total Reviews</p>
                <p class="text-3xl font-bold text-gray-900 mt-1"><?= number_format($totalReviews) ?></p>
            </div>
            <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <i class="fas fa-star text-green-600 text-xl"></i>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-gray-600">Feedbacks</p>
                <p class="text-3xl font-bold text-gray-900 mt-1"><?= number_format($totalFeedbacks) ?></p>
            </div>
            <div class="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                <i class="fas fa-comment text-red-600 text-xl"></i>
            </div>
        </div>
    </div>
</div>

<!-- Secondary Stats -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <p class="text-sm font-medium text-gray-600">Average Rating</p>
        <p class="text-3xl font-bold mt-1 <?= $avgRating >= 4 ? 'text-green-600' : ($avgRating >= 3 ? 'text-yellow-600' : 'text-red-600') ?>">
            <?= number_format($avgRating, 1) ?><span class="text-yellow-400 text-xl ml-1">★</span>
        </p>
    </div>
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <p class="text-sm font-medium text-gray-600">4★ & 5★ Reviews</p>
        <p class="text-3xl font-bold mt-1 text-gray-900"><?= number_format($highRatings) ?></p>
    </div>
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <p class="text-sm font-medium text-gray-600">Membership Split</p>
        <div class="flex flex-wrap gap-2 mt-2">
            <?php if (empty($membershipStats)): ?>
                <span class="text-xs text-gray-400">No cards yet</span>
            <?php else: foreach ($membershipStats as $m):
                $cls = $m['membership'] === 'pro'
                    ? 'bg-blue-100 text-blue-800'
                    : ($m['membership'] === 'enterprise'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-yellow-100 text-yellow-800');
            ?>
                <span class="px-2 py-1 text-xs font-medium rounded-full <?= $cls ?>">
                    <?= htmlspecialchars(ucfirst($m['membership'])) ?>: <?= (int)$m['count'] ?>
                </span>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>

<!-- Recent Activity -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">

    <!-- Recent Cards -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold text-gray-900">Recent Cards</h3>
            <a href="owner_cards.php" class="text-sm text-purple-600 hover:text-purple-800">View All</a>
        </div>
        <?php if (empty($recentCards)): ?>
            <p class="text-sm text-gray-400 py-6 text-center">No cards yet.</p>
        <?php else: ?>
        <div class="space-y-3">
            <?php foreach ($recentCards as $card): ?>
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="min-w-0">
                        <p class="text-sm font-medium text-gray-900 truncate"><?= htmlspecialchars($card['name']) ?></p>
                        <p class="text-xs text-gray-500 truncate">by <?= htmlspecialchars($card['user_email']) ?></p>
                    </div>
                    <?php
                        $mcls = $card['membership'] === 'pro'
                            ? 'bg-blue-100 text-blue-800'
                            : ($card['membership'] === 'enterprise'
                                ? 'bg-purple-100 text-purple-800'
                                : 'bg-yellow-100 text-yellow-800');
                    ?>
                    <span class="px-2 py-1 text-xs font-medium rounded-full <?= $mcls ?> flex-shrink-0 ml-2">
                        <?= htmlspecialchars(ucfirst($card['membership'])) ?>
                    </span>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Recent Users -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold text-gray-900">Recent Users</h3>
            <a href="owner_users.php" class="text-sm text-purple-600 hover:text-purple-800">View All</a>
        </div>
        <?php if (empty($recentUsers)): ?>
            <p class="text-sm text-gray-400 py-6 text-center">No users yet.</p>
        <?php else: ?>
        <div class="space-y-3">
            <?php foreach ($recentUsers as $u): ?>
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center min-w-0">
                        <div class="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <i class="fas fa-user text-purple-600 text-xs"></i>
                        </div>
                        <div class="ml-3 min-w-0">
                            <p class="text-sm font-medium text-gray-900 truncate"><?= htmlspecialchars($u['email']) ?></p>
                            <p class="text-xs text-gray-500"><?= timeAgo($u['created_at']) ?></p>
                        </div>
                    </div>
                    <?php if (isOwnerEmail($u['email'])): ?>
                        <span class="px-2 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800 flex-shrink-0 ml-2">
                            <i class="fas fa-crown mr-1"></i>Owner
                        </span>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Recent Reviews + Feedbacks -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-bold text-gray-900 mb-4">Recent Reviews</h3>
        <?php if (empty($recentReviews)): ?>
            <p class="text-sm text-gray-400 py-6 text-center">No reviews yet.</p>
        <?php else: ?>
        <div class="space-y-3">
            <?php foreach ($recentReviews as $r): ?>
                <div class="p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center justify-between mb-1">
                        <p class="text-sm font-medium text-gray-900 truncate">
                            <?= htmlspecialchars($r['customer_name'] ?: 'Anonymous') ?>
                        </p>
                        <div class="flex text-yellow-400 text-xs flex-shrink-0 ml-2">
                            <?php for ($i = 0; $i < 5; $i++): ?>
                                <i class="fas fa-star <?= $i < (int)$r['rating'] ? '' : 'text-gray-300' ?>"></i>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <p class="text-xs text-gray-600 line-clamp-2"><?= htmlspecialchars(mb_strimwidth((string)$r['body'], 0, 120, '…')) ?></p>
                    <p class="text-xs text-gray-400 mt-1">
                        on <span class="font-medium"><?= htmlspecialchars($r['card_name']) ?></span> · <?= timeAgo($r['created_at']) ?>
                    </p>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-bold text-gray-900 mb-4">Recent Feedbacks</h3>
        <?php if (empty($recentFeedbacks)): ?>
            <p class="text-sm text-gray-400 py-6 text-center">No feedback yet.</p>
        <?php else: ?>
        <div class="space-y-3">
            <?php foreach ($recentFeedbacks as $f): ?>
                <div class="p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center justify-between mb-1">
                        <p class="text-sm font-medium text-gray-900 truncate"><?= htmlspecialchars($f['customer_name']) ?></p>
                        <span class="px-2 py-0.5 text-xs font-medium rounded-full
                            <?= $f['status'] === 'new' ? 'bg-red-100 text-red-800'
                                : ($f['status'] === 'read' ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-green-100 text-green-800') ?>">
                            <?= htmlspecialchars(ucfirst($f['status'])) ?>
                        </span>
                    </div>
                    <p class="text-xs text-gray-600 line-clamp-2"><?= htmlspecialchars(mb_strimwidth((string)$f['message'], 0, 120, '…')) ?></p>
                    <p class="text-xs text-gray-400 mt-1">
                        on <span class="font-medium"><?= htmlspecialchars($f['card_name']) ?></span> · <?= timeAgo($f['created_at']) ?>
                    </p>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/includes/owner_layout.php';