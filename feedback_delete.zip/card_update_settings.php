<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: dashboard.php'); exit; }

$userId = (int)$_SESSION['user_id'];
$cardId = (int)($_POST['card_id'] ?? 0);
$slug   = trim($_POST['slug'] ?? '');

$stmt = $conn->prepare("SELECT * FROM review_cards WHERE id = ? AND user_id = ? LIMIT 1");
$stmt->execute([$cardId, $userId]);
$card = $stmt->fetch();
if (!$card) { header('Location: dashboard.php'); exit; }

$details = json_decode($card['details'] ?? '{}', true);
if (!is_array($details)) $details = [];

$name = trim($_POST['name'] ?? $card['name']);
if ($name === '') $name = $card['name'];

$details['description']       = trim($_POST['description'] ?? '');
$details['whatsapp']          = trim($_POST['whatsapp'] ?? '');
$details['facebook']          = trim($_POST['facebook'] ?? '');
$details['instagram']         = trim($_POST['instagram'] ?? '');
$details['website']           = trim($_POST['website'] ?? '');
$details['google_review_url'] = trim($_POST['google_review_url'] ?? '');
$details['theme']             = $_POST['theme'] ?? 'purple';
$details['enable_keyword_selection'] = !empty($_POST['enable_keyword_selection']);

$kw = array_filter(array_map('trim', explode(',', $_POST['business_keywords'] ?? '')));
$details['business_keywords'] = array_values($kw);

/* Logo upload */
if (!empty($_POST['remove_logo'])) {
    $details['logo'] = '';
} elseif (!empty($_FILES['logo']['tmp_name']) && is_uploaded_file($_FILES['logo']['tmp_name'])) {
    $allowed = ['jpg','jpeg','png','gif','webp'];
    $ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
    if (in_array($ext, $allowed) && $_FILES['logo']['size'] <= 2 * 1024 * 1024) {
        $dir = __DIR__ . '/assets/uploads';
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $fname = 'logo_' . $cardId . '_' . time() . '.' . $ext;
        if (move_uploaded_file($_FILES['logo']['tmp_name'], $dir . '/' . $fname)) {
            $details['logo'] = 'assets/uploads/' . $fname;
        }
    }
}

$stmt = $conn->prepare("UPDATE review_cards SET name = ?, details = ? WHERE id = ?");
$stmt->execute([$name, json_encode($details), $cardId]);

$_SESSION['settings_success'] = 'Settings saved successfully.';
header('Location: card_settings.php?slug=' . urlencode($card['slug']));
exit;