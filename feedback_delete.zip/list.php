<?php
/**
 * list.php — User's review cards
 * Only redirects to onboard.php when the user genuinely has zero cards.
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$appName = getSetting('app_name', 'App');
$userId  = (int)$_SESSION['user_id'];

/* ---------- Fetch user's review cards ---------- */
$stmt = $conn->prepare("
    SELECT rc.*,
           COUNT(r.id)   AS review_count,
           AVG(r.rating) AS avg_rating
    FROM review_cards rc
    LEFT JOIN reviews r ON rc.id = r.card_id
    WHERE rc.user_id = ?
    GROUP BY rc.id
    ORDER BY rc.created_at DESC
");
$stmt->execute([$userId]);
$cards = $stmt->fetchAll();

/* Redirect only if the user has never created a card.
   (onboard.php does NOT bounce back, so no loop.) */
if (empty($cards)) {
    header('Location: onboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Review Cards | <?= htmlspecialchars($appName) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="bg-gray-50 min-h-screen">

    <!-- Navigation -->
    <nav class="bg-white border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <a href="list.php" class="text-xl font-bold text-gray-900"><?= htmlspecialchars($appName) ?></a>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600 hidden sm:inline"><?= htmlspecialchars($_SESSION['user_email'] ?? '') ?></span>
                    <a href="logout.php" class="text-sm text-red-600 hover:text-red-800 font-medium">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        <!-- Success message -->
        <?php if (!empty($_SESSION['success_message'])): ?>
            <div class="mb-6 flex items-center p-4 text-sm text-green-800 border-t-4 border-green-300 bg-green-50 rounded-lg" role="alert">
                <i class="fas fa-check-circle mr-2"></i>
                <div><?= htmlspecialchars($_SESSION['success_message']) ?></div>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <!-- Header -->
        <div class="flex justify-between items-center mb-8">
            <div>
                <h2 class="text-3xl font-bold text-gray-900">My Review Cards</h2>
                <p class="text-gray-500 mt-1">Collect and manage AI-powered reviews</p>
            </div>
            <a href="onboard.php"
               class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-xl transition-all transform active:scale-95 shadow-lg">
                <i class="fas fa-plus mr-2"></i>
                Create Card
            </a>
        </div>

        <!-- Card Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($cards as $card): ?>
                <div class="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-xl transition-shadow duration-300">

                    <!-- Header -->
                    <div class="p-6 border-b border-gray-100">
                        <div class="flex justify-between items-start mb-2">
                            <h3 class="text-lg font-bold text-gray-900 truncate flex-1">
                                <?= htmlspecialchars($card['name']) ?>
                            </h3>
                            <?php
                                $mcls = $card['membership'] === 'trial'
                                    ? 'bg-yellow-100 text-yellow-800'
                                    : ($card['membership'] === 'pro'
                                        ? 'bg-blue-100 text-blue-800'
                                        : 'bg-green-100 text-green-800');
                            ?>
                            <span class="ml-2 px-2 py-1 text-xs font-medium rounded-full <?= $mcls ?>">
                                <?= htmlspecialchars(ucfirst($card['membership'])) ?>
                            </span>
                        </div>
                        <p class="text-sm text-gray-500 mb-4 truncate font-mono">
                            <?= htmlspecialchars(url('review.php?slug=' . urlencode($card['slug']))) ?>
                        </p>

                        <!-- Stats -->
                        <div class="flex space-x-4 text-sm text-gray-600">
                            <div class="flex items-center">
                                <i class="fas fa-comment mr-1 text-gray-400"></i>
                                <?= (int)$card['review_count'] ?> reviews
                            </div>
                            <div class="flex items-center">
                                <i class="fas fa-star text-yellow-400 mr-1"></i>
                                <?= $card['review_count'] > 0 ? number_format((float)$card['avg_rating'], 1) : '0.0' ?>
                            </div>
                        </div>
                    </div>

                    <!-- Footer -->
                    <div class="px-6 py-4 bg-gray-50 flex space-x-3">
                        <a href="review.php?slug=<?= urlencode($card['slug']) ?>"
                           target="_blank"
                           class="flex-1 inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-blue-700 bg-blue-100 hover:bg-blue-200 rounded-lg transition-colors">
                            <i class="fas fa-eye mr-1"></i> View
                        </a>
                        <a href="card_home.php?slug=<?= urlencode($card['slug']) ?>"
                           class="flex-1 inline-flex justify-center items-center px-4 py-2 text-sm font-medium text-white bg-gray-900 hover:bg-gray-800 rounded-lg transition-colors">
                            <i class="fas fa-sliders-h mr-1"></i> Manage
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>