<?php
/**
 * onboard.php — Create a review card
 * Handles its own POST. On success → redirects to list.php.
 * On error → re-renders with the error message.
 * No external POST target, no redirect loops.
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$appName = getSetting('app_name', 'App');
$userId  = (int)$_SESSION['user_id'];
$errors  = [];

/* ---------- Handle POST (create card) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name   = trim($_POST['name'] ?? '');
    $slugIn = trim($_POST['slug'] ?? '');

    if ($name === '') {
        $errors[] = 'Business name is required.';
    }

    if (empty($errors)) {
        try {
            $slug = uniqueCardSlug($slugIn !== '' ? $slugIn : $name);

            $stmt = $conn->prepare("
                INSERT INTO review_cards (user_id, name, slug, membership, expiry_date)
                VALUES (?, ?, ?, 'trial', DATE_ADD(NOW(), INTERVAL 3 DAY))
            ");
            $stmt->execute([$userId, $name, $slug]);

            $_SESSION['success_message'] = 'Review card created successfully!';
            header('Location: list.php');
            exit;

        } catch (Exception $e) {
            $errors[] = 'Could not create card: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Review Card | <?= htmlspecialchars($appName) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen p-4">

    <div class="w-full max-w-md bg-white p-8 rounded-2xl shadow-xl border border-gray-100">

        <!-- Header -->
        <div class="mb-8 text-center">
            <div class="flex justify-center mb-4">
                <div class="bg-blue-100 p-3 rounded-full">
                    <i class="fas fa-id-card text-3xl text-blue-600"></i>
                </div>
            </div>
            <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight">Create Your Review Card</h1>
            <p class="text-gray-500 mt-2">Start collecting AI-powered reviews in minutes.</p>
        </div>

        <!-- Errors -->
        <?php if ($errors): ?>
            <div class="mb-6 flex items-start p-4 text-sm text-red-800 border-t-4 border-red-300 bg-red-50 rounded-lg" role="alert">
                <i class="fas fa-exclamation-circle mr-2 mt-0.5"></i>
                <div>
                    <?php foreach ($errors as $e): ?>
                        <p><?= htmlspecialchars($e) ?></p>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Form (posts to itself) -->
        <form method="POST" id="onboardForm" class="space-y-5">

            <div>
                <label for="name" class="block text-sm font-semibold text-gray-700 mb-1">Business Name</label>
                <input type="text" id="name" name="name" required
                    value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                    class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                    placeholder="e.g., Food Bites"
                    maxlength="255"
                    autofocus>
            </div>

            <input type="hidden" id="slug" name="slug" value="<?= htmlspecialchars($_POST['slug'] ?? '') ?>">

            <div id="slugPreview" class="<?= empty($_POST['slug']) ? 'hidden' : '' ?>">
                <label class="block text-sm font-semibold text-gray-700 mb-1">Your Review Page URL</label>
                <div class="flex items-center bg-gray-50 px-4 py-3 rounded-xl border border-gray-200 overflow-hidden">
                    <span class="text-gray-500 text-sm truncate"><?= htmlspecialchars(url('review.php?slug=')) ?></span>
                    <span id="slugText" class="text-blue-600 font-medium text-sm truncate"><?= htmlspecialchars($_POST['slug'] ?? '') ?></span>
                </div>
            </div>

            <!-- Trial Info -->
            <div class="bg-blue-50 p-4 rounded-xl border border-blue-100">
                <div class="flex items-start">
                    <i class="fas fa-info-circle text-blue-600 mt-0.5 mr-2 flex-shrink-0"></i>
                    <div>
                        <p class="text-sm text-blue-800 font-medium">3-Day Free Trial</p>
                        <p class="text-xs text-blue-600">No credit card required. Upgrade anytime.</p>
                    </div>
                </div>
            </div>

            <button type="submit"
                class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-xl shadow-lg transition-all transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                id="submitBtn"
                <?= empty($_POST['slug']) ? 'disabled' : '' ?>>
                Create Review Card
            </button>
        </form>

        <div class="mt-8 text-center border-t border-gray-100 pt-6">
            <a href="list.php" class="text-sm text-blue-600 font-bold hover:underline">
                <i class="fas fa-arrow-left mr-1"></i> Back to my cards
            </a>
        </div>
    </div>

    <script>
        $(function() {
            // Live slug update
            $('#name').on('input', function() {
                const name = $(this).val().trim();

                if (name.length > 0) {
                    const slug = name
                        .toLowerCase()
                        .replace(/[^a-z0-9\s-]/g, '')
                        .replace(/\s+/g, '-')
                        .replace(/-+/g, '-')
                        .replace(/^-|-$/g, '');

                    $('#slug').val(slug);
                    $('#slugText').text(slug);
                    $('#slugPreview').removeClass('hidden');
                    $('#submitBtn').prop('disabled', slug.length === 0);
                } else {
                    $('#slug').val('');
                    $('#slugPreview').addClass('hidden');
                    $('#submitBtn').prop('disabled', true);
                }
            });
        });
    </script>
</body>
</html>