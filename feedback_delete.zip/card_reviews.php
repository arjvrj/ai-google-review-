<?php
/**
 * card_reviews.php — Card panel reviews & feedback manager
 * URL: card_reviews.php?slug=<slug>&filter=reviews|feedback&search=...&page=N
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$page   = 'reviews';
$slug   = trim($_GET['slug'] ?? '');
$userId = (int)$_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM review_cards WHERE slug = ? AND user_id = ? LIMIT 1");
$stmt->execute([$slug, $userId]);
$card = $stmt->fetch();

if (!$card) {
    header('Location: dashboard.php');
    exit;
}

$filter = $_GET['filter'] ?? 'reviews';
$search = trim($_GET['search'] ?? '');
$pageNum = max(1, (int)($_GET['page'] ?? 1));
$limit  = 20;
$offset = ($pageNum - 1) * $limit;

/* ---------- Stats ---------- */
$statsStmt = $conn->prepare("
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN rating >= 4 THEN 1 ELSE 0 END) AS high,
        SUM(CASE WHEN rating <= 3 THEN 1 ELSE 0 END) AS low,
        AVG(rating) AS avg
    FROM reviews WHERE card_id = ?
");
$statsStmt->execute([$card['id']]);
$statsData = $statsStmt->fetch() ?: [];

$stats = [
    'total_reviews' => (int)($statsData['total'] ?? 0),
    'high'          => (int)($statsData['high'] ?? 0),
    'low'           => (int)($statsData['low'] ?? 0),
    'avg'           => (float)($statsData['avg'] ?? 0),
];

$fbStmt = $conn->prepare("SELECT COUNT(*) FROM feedbacks WHERE card_id = ?");
$fbStmt->execute([$card['id']]);
$stats['feedbacks'] = (int)$fbStmt->fetchColumn();

/* ---------- Fetch reviews ---------- */
$reviews = [];
$totalReviews = 0;
$totalPages = 0;

if ($filter === 'all' || $filter === 'reviews') {
    $where = ['card_id = ?'];
    $params = [$card['id']];

    if ($search !== '') {
        $where[] = '(customer_name LIKE ? OR body LIKE ?)';
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    $whereClause = implode(' AND ', $where);

    $countStmt = $conn->prepare("SELECT COUNT(*) FROM reviews WHERE $whereClause");
    $countStmt->execute($params);
    $totalReviews = (int)$countStmt->fetchColumn();
    $totalPages = (int)ceil($totalReviews / $limit);

    $stmt = $conn->prepare("SELECT * FROM reviews WHERE $whereClause ORDER BY created_at DESC LIMIT $limit OFFSET $offset");
    $stmt->execute($params);
    $reviews = $stmt->fetchAll();
}

/* ---------- Fetch feedback ---------- */
$feedbacks = [];
if ($filter === 'all' || $filter === 'feedback') {
    $where = ['card_id = ?'];
    $params = [$card['id']];

    if ($search !== '') {
        $where[] = '(customer_name LIKE ? OR message LIKE ? OR email LIKE ? OR phone LIKE ?)';
        $params[] = "%$search%"; $params[] = "%$search%";
        $params[] = "%$search%"; $params[] = "%$search%";
    }
    $whereClause = implode(' AND ', $where);

    $stmt = $conn->prepare("SELECT * FROM feedbacks WHERE $whereClause ORDER BY created_at DESC");
    $stmt->execute($params);
    $feedbacks = $stmt->fetchAll();
}

$slugEnc = urlencode($card['slug']);
$baseUrl = "card_reviews.php?slug={$slugEnc}";

ob_start();
?>

<div class="mb-8">
    <h2 class="text-2xl font-bold text-gray-900">Manage Reviews & Feedback</h2>
    <p class="text-gray-600 mt-1">View all customer reviews and feedback submissions.</p>
</div>

<!-- Stats -->
<div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <p class="text-xs text-gray-500 uppercase font-semibold">Total Reviews</p>
        <p class="text-2xl font-bold text-gray-900"><?= number_format($stats['total_reviews']) ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <p class="text-xs text-gray-500 uppercase font-semibold">Avg Rating</p>
        <p class="text-2xl font-bold <?= $stats['avg'] >= 4 ? 'text-green-600' : ($stats['avg'] >= 3 ? 'text-yellow-600' : 'text-red-600') ?>">
            <?= number_format($stats['avg'], 1) ?>⭐
        </p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <p class="text-xs text-gray-500 uppercase font-semibold">High (4-5⭐)</p>
        <p class="text-2xl font-bold text-green-600"><?= number_format($stats['high']) ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <p class="text-xs text-gray-500 uppercase font-semibold">Low (1-3⭐)</p>
        <p class="text-2xl font-bold text-orange-600"><?= number_format($stats['low']) ?></p>
    </div>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <p class="text-xs text-gray-500 uppercase font-semibold">Feedbacks</p>
        <p class="text-2xl font-bold text-red-600"><?= number_format($stats['feedbacks']) ?></p>
    </div>
</div>

<!-- Filters -->
<div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-6">
    <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div class="flex flex-wrap gap-2">
            <a href="<?= $baseUrl ?>&filter=reviews"
               class="px-4 py-2 text-sm rounded-lg <?= $filter === 'reviews' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?>">
                <i class="fas fa-comment mr-1"></i> Reviews
            </a>
            <a href="<?= $baseUrl ?>&filter=feedback"
               class="px-4 py-2 text-sm rounded-lg <?= $filter === 'feedback' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?>">
                <i class="fas fa-bullhorn mr-1"></i> Feedbacks
            </a>
        </div>
        <form method="GET" class="flex items-center gap-2 w-full md:w-auto">
            <input type="hidden" name="slug" value="<?= htmlspecialchars($card['slug']) ?>">
            <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
            <input type="text" name="search" placeholder="Search..."
                   value="<?= htmlspecialchars($search) ?>"
                   class="flex-1 md:w-48 px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm">
            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
                <i class="fas fa-search"></i>
            </button>
            <?php if ($search !== ''): ?>
                <a href="<?= $baseUrl ?>&filter=<?= urlencode($filter) ?>" class="px-3 py-2 text-gray-500 hover:text-gray-700 text-sm">
                    <i class="fas fa-times"></i>
                </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- List -->
<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">

    <?php if ($filter === 'feedback'): ?>
        <?php if (count($feedbacks) > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50 border-b border-gray-200">
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Customer</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Contact</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Rating</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Message</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Status</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Date</th>
                            <th class="text-center py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($feedbacks as $fb): ?>
                            <tr class="border-b border-gray-100 hover:bg-gray-50 <?= $fb['status'] === 'new' ? 'bg-blue-50' : '' ?>">
                                <td class="py-3 px-4"><p class="text-sm font-medium text-gray-900"><?= htmlspecialchars($fb['customer_name']) ?></p></td>
                                <td class="py-3 px-4">
                                    <p class="text-sm text-gray-600"><?= htmlspecialchars($fb['email']) ?></p>
                                    <p class="text-xs text-gray-500"><?= htmlspecialchars($fb['phone']) ?></p>
                                </td>
                                <td class="py-3 px-4"><span class="text-sm font-bold text-red-500"><?= (int)$fb['rating'] ?>★</span></td>
                                <td class="py-3 px-4"><p class="text-sm text-gray-600 max-w-xs truncate"><?= htmlspecialchars($fb['message']) ?></p></td>
                                <td class="py-3 px-4">
                                    <?php
                                    $scls = $fb['status'] === 'new' ? 'bg-red-100 text-red-800'
                                          : ($fb['status'] === 'read' ? 'bg-yellow-100 text-yellow-800'
                                          : 'bg-green-100 text-green-800');
                                    ?>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?= $scls ?>">
                                        <?= htmlspecialchars(ucfirst($fb['status'])) ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4"><span class="text-sm text-gray-500"><?= date('M d, Y', strtotime($fb['created_at'])) ?></span></td>
                                <td class="py-3 px-4">
                                    <div class="flex items-center justify-center space-x-2">
                                        <?php if ($fb['status'] === 'new'): ?>
                                            <button onclick="markFeedbackRead(<?= (int)$fb['id'] ?>)"
                                                    class="p-1.5 text-yellow-600 hover:bg-yellow-50 rounded-lg" title="Mark as Read">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        <?php endif; ?>
                                        <button onclick='viewFeedback(<?= json_encode($fb, JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP) ?>)'
                                                class="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="View">
                                            <i class="fas fa-search"></i>
                                        </button>
                                        <button onclick="deleteFeedback(<?= (int)$fb['id'] ?>)"
                                                class="p-1.5 text-red-600 hover:bg-red-50 rounded-lg" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-bullhorn text-gray-300 text-5xl mb-4"></i>
                <h3 class="text-lg font-medium text-gray-900 mb-1">No feedbacks yet</h3>
                <p class="text-gray-500 text-sm">Customers haven't submitted any feedback forms.</p>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <?php if (count($reviews) > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50 border-b border-gray-200">
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Customer</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Rating</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Review</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Type</th>
                            <th class="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Date</th>
                            <th class="text-center py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reviews as $r): ?>
                            <?php
                            $rating = (int)$r['rating'];
                            $starColor = $rating >= 4 ? 'text-green-500' : ($rating >= 3 ? 'text-yellow-500' : 'text-red-500');
                            $details = json_decode($r['details'] ?? '{}', true);
                            $isAI = !empty($details['ai_generated']);
                            ?>
                            <tr class="border-b border-gray-100 hover:bg-gray-50">
                                <td class="py-3 px-4"><p class="text-sm font-medium text-gray-900"><?= htmlspecialchars($r['customer_name'] ?: 'Anonymous') ?></p></td>
                                <td class="py-3 px-4"><span class="text-sm font-bold <?= $starColor ?>"><?= $rating ?>★</span></td>
                                <td class="py-3 px-4"><p class="text-sm text-gray-600 max-w-xs truncate"><?= htmlspecialchars($r['body'] ?: 'No comment') ?></p></td>
                                <td class="py-3 px-4">
                                    <?php if ($isAI): ?>
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                            <i class="fas fa-robot mr-1"></i> AI
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                            <i class="fas fa-user mr-1"></i> Customer
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4"><span class="text-sm text-gray-500"><?= date('M d, Y', strtotime($r['created_at'])) ?></span></td>
                                <td class="py-3 px-4">
                                    <div class="flex items-center justify-center space-x-2">
                                        <button onclick='viewReview(<?= json_encode($r, JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP) ?>)'
                                                class="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="View">
                                            <i class="fas fa-search"></i>
                                        </button>
                                        <button onclick="deleteReview(<?= (int)$r['id'] ?>)"
                                                class="p-1.5 text-red-600 hover:bg-red-50 rounded-lg" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): ?>
                <div class="px-4 py-3 border-t border-gray-200 flex items-center justify-between">
                    <p class="text-sm text-gray-600">
                        Showing <?= $offset + 1 ?> - <?= min($offset + $limit, $totalReviews) ?> of <?= $totalReviews ?>
                    </p>
                    <div class="flex space-x-2">
                        <?php if ($pageNum > 1): ?>
                            <a href="<?= $baseUrl ?>&filter=<?= urlencode($filter) ?>&search=<?= urlencode($search) ?>&page=<?= $pageNum - 1 ?>"
                               class="px-3 py-1 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Previous</a>
                        <?php endif; ?>
                        <?php if ($pageNum < $totalPages): ?>
                            <a href="<?= $baseUrl ?>&filter=<?= urlencode($filter) ?>&search=<?= urlencode($search) ?>&page=<?= $pageNum + 1 ?>"
                               class="px-3 py-1 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">Next</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

        <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-comment text-gray-300 text-5xl mb-4"></i>
                <h3 class="text-lg font-medium text-gray-900 mb-1">No reviews found</h3>
                <p class="text-gray-500 text-sm">
                    <?= $search !== '' ? 'No reviews match your search.' : 'Share your review page to start collecting reviews.' ?>
                </p>
                <?php if ($search !== ''): ?>
                    <a href="<?= $baseUrl ?>&filter=<?= urlencode($filter) ?>" class="inline-block mt-4 text-blue-600 hover:text-blue-700 text-sm font-medium">Clear search →</a>
                <?php else: ?>
                    <a href="review.php?slug=<?= urlencode($card['slug']) ?>" target="_blank" class="inline-block mt-4 text-blue-600 hover:text-blue-700 text-sm font-medium">Open your review page →</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<!-- Review Modal -->
<div id="viewReviewModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-2xl max-w-lg w-full p-6">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold text-gray-900">Review Details</h3>
            <button onclick="closeViewModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
        </div>
        <div id="reviewDetails" class="space-y-4"></div>
    </div>
</div>

<!-- Feedback Modal -->
<div id="viewFeedbackModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50 p-4">
    <div class="bg-white rounded-2xl max-w-lg w-full p-6">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold text-gray-900">Feedback Details</h3>
            <button onclick="closeFeedbackModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
        </div>
        <div id="feedbackDetails" class="space-y-4"></div>
    </div>
</div>

<!-- Toast -->
<div id="toast" class="fixed bottom-4 right-4 bg-gray-900 text-white px-6 py-3 rounded-xl shadow-lg z-50 hidden items-center">
    <i class="fas fa-check-circle text-green-400 mr-2"></i>
    <span id="toastMessage">Done</span>
</div>

<script>
function showToast(msg) {
    $('#toastMessage').text(msg);
    $('#toast').removeClass('hidden').addClass('flex');
    setTimeout(() => $('#toast').addClass('hidden').removeClass('flex'), 2500);
}

function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
        '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    }[c]));
}

function viewReview(r) {
    const stars = '★'.repeat(r.rating) + '☆'.repeat(5 - r.rating);
    const details = (() => { try { return JSON.parse(r.details || '{}'); } catch(e) { return {}; } })();
    const isAI = details.ai_generated === true;

    $('#reviewDetails').html(`
        <div class="border-b border-gray-100 pb-4">
            <p class="text-sm text-gray-500">Customer</p>
            <p class="text-gray-900 font-medium">${escapeHtml(r.customer_name || 'Anonymous')}</p>
        </div>
        <div class="border-b border-gray-100 pb-4">
            <p class="text-sm text-gray-500">Rating</p>
            <p class="text-2xl font-bold ${r.rating >= 4 ? 'text-green-500' : r.rating >= 3 ? 'text-yellow-500' : 'text-red-500'}">${stars}</p>
        </div>
        <div class="border-b border-gray-100 pb-4">
            <p class="text-sm text-gray-500">Review</p>
            <p class="text-gray-900">${escapeHtml(r.body || 'No comment')}</p>
        </div>
        <div class="border-b border-gray-100 pb-4">
            <p class="text-sm text-gray-500">Type</p>
            <p class="text-gray-900">${isAI ? '🤖 AI Generated' : '👤 Customer'}</p>
        </div>
        <div>
            <p class="text-sm text-gray-500">Date</p>
            <p class="text-gray-900">${new Date(r.created_at).toLocaleString()}</p>
        </div>
    `);
    $('#viewReviewModal').removeClass('hidden').addClass('flex');
}

function viewFeedback(fb) {
    $('#feedbackDetails').html(`
        <div class="border-b border-gray-100 pb-4">
            <p class="text-sm text-gray-500">Customer</p>
            <p class="text-gray-900 font-medium">${escapeHtml(fb.customer_name)}</p>
        </div>
        <div class="border-b border-gray-100 pb-4">
            <p class="text-sm text-gray-500">Contact</p>
            <p class="text-gray-900">📧 ${escapeHtml(fb.email || 'N/A')}</p>
            <p class="text-gray-900">📱 ${escapeHtml(fb.phone || 'N/A')}</p>
        </div>
        <div class="border-b border-gray-100 pb-4">
            <p class="text-sm text-gray-500">Rating</p>
            <p class="text-2xl font-bold text-red-500">${fb.rating}★</p>
        </div>
        <div class="border-b border-gray-100 pb-4">
            <p class="text-sm text-gray-500">Message</p>
            <p class="text-gray-900">${escapeHtml(fb.message)}</p>
        </div>
        <div class="border-b border-gray-100 pb-4">
            <p class="text-sm text-gray-500">Status</p>
            <p class="text-gray-900 capitalize">${escapeHtml(fb.status)}</p>
        </div>
        <div>
            <p class="text-sm text-gray-500">Date</p>
            <p class="text-gray-900">${new Date(fb.created_at).toLocaleString()}</p>
        </div>
    `);
    $('#viewFeedbackModal').removeClass('hidden').addClass('flex');
    if (fb.status === 'new') markFeedbackRead(fb.id, true);
}

function deleteReview(id) {
    if (!confirm('Delete this review? This cannot be undone.')) return;
    $.post('review_delete.php', { review_id: id }, function(res) {
        if (res.success) { showToast('Review deleted'); setTimeout(() => location.reload(), 1200); }
        else showToast('Error: ' + (res.error || 'Unknown'));
    }, 'json').fail(() => showToast('An error occurred.'));
}

function deleteFeedback(id) {
    if (!confirm('Delete this feedback?')) return;
    $.post('feedback_delete.php', { feedback_id: id }, function(res) {
        if (res.success) { showToast('Feedback deleted'); setTimeout(() => location.reload(), 1200); }
        else showToast('Error: ' + (res.error || 'Unknown'));
    }, 'json').fail(() => showToast('An error occurred.'));
}

function markFeedbackRead(id, silent = false) {
    $.post('feedback_mark_read.php', { feedback_id: id }, function(res) {
        if (res.success && !silent) {
            showToast('Marked as read');
            setTimeout(() => location.reload(), 1200);
        }
    }, 'json');
}

function closeViewModal()      { $('#viewReviewModal').addClass('hidden').removeClass('flex'); }
function closeFeedbackModal()  { $('#viewFeedbackModal').addClass('hidden').removeClass('flex'); }

$(document).keydown(e => { if (e.key === 'Escape') { closeViewModal(); closeFeedbackModal(); } });
$('#viewReviewModal').click(e => { if (e.target === this) closeViewModal(); });
$('#viewFeedbackModal').click(e => { if (e.target === this) closeFeedbackModal(); });
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/includes/card_layout.php';