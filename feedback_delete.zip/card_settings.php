<?php
/**
 * card_settings.php — Card settings (basic info, contacts, theme, AI keywords)
 * URL: card_settings.php?slug=<slug>
 * POSTs to card_update_settings.php (multipart, handles logo upload)
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$page   = 'settings';
$slug   = trim($_GET['slug'] ?? '');
$userId = (int)$_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM review_cards WHERE slug = ? AND user_id = ? LIMIT 1");
$stmt->execute([$slug, $userId]);
$card = $stmt->fetch();

if (!$card) {
    header('Location: dashboard.php');
    exit;
}

/* ---------- Themes ---------- */
$themes = [
    'purple' => ['name' => 'Purple',  'preview' => 'linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%)'],
    'blue'   => ['name' => 'Blue',    'preview' => 'linear-gradient(135deg, #2563eb 0%, #0891b2 100%)'],
    'pink'   => ['name' => 'Pink',    'preview' => 'linear-gradient(135deg, #db2777 0%, #e11d48 100%)'],
    'orange' => ['name' => 'Orange',  'preview' => 'linear-gradient(135deg, #ea580c 0%, #d97706 100%)'],
    'green'  => ['name' => 'Green',   'preview' => 'linear-gradient(135deg, #059669 0%, #047857 100%)'],
    'red'    => ['name' => 'Red',     'preview' => 'linear-gradient(135deg, #dc2626 0%, #e11d48 100%)'],
    'indigo' => ['name' => 'Indigo',  'preview' => 'linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%)'],
    'teal'   => ['name' => 'Teal',    'preview' => 'linear-gradient(135deg, #0d9488 0%, #0891b2 100%)'],
    'rose'   => ['name' => 'Rose',    'preview' => 'linear-gradient(135deg, #e11d48 0%, #dc2626 100%)'],
    'amber'  => ['name' => 'Amber',   'preview' => 'linear-gradient(135deg, #d97706 0%, #ca8a04 100%)'],
];

$details = json_decode($card['details'] ?? '{}', true);
if (!is_array($details)) $details = [];

$business = [
    'name'               => $card['name'],
    'logo'               => $details['logo'] ?? '',
    'description'        => $details['description'] ?? '',
    'whatsapp'           => $details['whatsapp'] ?? '',
    'facebook'           => $details['facebook'] ?? '',
    'instagram'          => $details['instagram'] ?? '',
    'website'            => $details['website'] ?? '',
    'google_review_url'  => $details['google_review_url'] ?? '',
    'business_keywords'  => $details['business_keywords'] ?? ['professional', 'quality', 'excellent service'],
    'theme'              => $details['theme'] ?? 'purple',
    'enable_keyword_selection' => $details['enable_keyword_selection'] ?? true,
];

ob_start();
?>

<div class="mb-8">
    <h2 class="text-2xl font-bold text-gray-900">Card Settings</h2>
    <p class="text-gray-600 mt-1">Manage your review card and AI review settings.</p>
</div>

<?php if (!empty($_SESSION['settings_success'])): ?>
    <div class="mb-6 flex items-center p-4 text-sm text-green-800 border-t-4 border-green-300 bg-green-50 rounded-lg">
        <i class="fas fa-check-circle mr-2"></i>
        <div><?= htmlspecialchars($_SESSION['settings_success']) ?></div>
    </div>
    <?php unset($_SESSION['settings_success']); ?>
<?php endif; ?>

<?php if (!empty($_SESSION['settings_error'])): ?>
    <div class="mb-6 flex items-center p-4 text-sm text-red-800 border-t-4 border-red-300 bg-red-50 rounded-lg">
        <i class="fas fa-exclamation-circle mr-2"></i>
        <div><?= htmlspecialchars($_SESSION['settings_error']) ?></div>
    </div>
    <?php unset($_SESSION['settings_error']); ?>
<?php endif; ?>

<form action="card_update_settings.php" method="POST" enctype="multipart/form-data" class="space-y-6">
    <input type="hidden" name="card_id" value="<?= (int)$card['id'] ?>">
    <input type="hidden" name="slug" value="<?= htmlspecialchars($card['slug']) ?>">

    <!-- Basic -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-bold text-gray-900 mb-4">Basic Information</h3>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">Business Name</label>
            <input type="text" name="name" value="<?= htmlspecialchars($business['name']) ?>" required
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">Logo</label>
            <div class="flex items-start space-x-4">
                <div id="logoPreviewContainer" class="w-24 h-24 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden">
                    <?php if (!empty($business['logo'])): ?>
                        <img src="<?= htmlspecialchars(url($business['logo'])) ?>" alt="Logo" id="logoPreview" class="w-full h-full object-cover">
                    <?php else: ?>
                        <i class="fas fa-image text-gray-400 text-2xl" id="logoPlaceholder"></i>
                    <?php endif; ?>
                </div>
                <div class="flex-1">
                    <input type="file" name="logo" id="logo" accept="image/*"
                           class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                    <p class="text-xs text-gray-400 mt-1">Square image recommended, max 2MB</p>
                    <?php if (!empty($business['logo'])): ?>
                        <label class="inline-flex items-center mt-2">
                            <input type="checkbox" name="remove_logo" value="1" class="rounded border-gray-300 text-red-600 focus:ring-red-500">
                            <span class="ml-2 text-sm text-red-600">Remove logo</span>
                        </label>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Business Description</label>
            <textarea name="description" rows="3"
                      class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      placeholder="Tell customers about your business..."><?= htmlspecialchars($business['description']) ?></textarea>
        </div>
    </div>

    <!-- Contact & Social -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-bold text-gray-900 mb-4">Contact & Social Links</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    <i class="fab fa-whatsapp text-green-500 mr-1"></i> WhatsApp Number
                </label>
                <input type="tel" name="whatsapp" value="<?= htmlspecialchars($business['whatsapp']) ?>"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                       placeholder="+1234567890">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    <i class="fab fa-facebook text-blue-600 mr-1"></i> Facebook URL
                </label>
                <input type="url" name="facebook" value="<?= htmlspecialchars($business['facebook']) ?>"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                       placeholder="https://facebook.com/yourpage">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    <i class="fab fa-instagram text-pink-600 mr-1"></i> Instagram URL
                </label>
                <input type="url" name="instagram" value="<?= htmlspecialchars($business['instagram']) ?>"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                       placeholder="https://instagram.com/yourpage">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    <i class="fas fa-globe text-gray-600 mr-1"></i> Website URL
                </label>
                <input type="url" name="website" value="<?= htmlspecialchars($business['website']) ?>"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                       placeholder="https://yourwebsite.com">
            </div>
        </div>

        <div class="mt-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">
                <i class="fab fa-google text-blue-500 mr-1"></i> Google Review URL
            </label>
            <input type="url" name="google_review_url" value="<?= htmlspecialchars($business['google_review_url']) ?>"
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                   placeholder="https://www.google.com/search?q=your+business+review">
            <p class="text-xs text-gray-400 mt-1">Customers get redirected here after copying the AI review.</p>
        </div>
    </div>

    <!-- Theme -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-bold text-gray-900 mb-4">
            <i class="fas fa-palette text-purple-600 mr-2"></i> Theme Selection
        </h3>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            <?php foreach ($themes as $key => $theme): ?>
                <label class="relative cursor-pointer">
                    <input type="radio" name="theme" value="<?= $key ?>" class="sr-only peer" <?= $business['theme'] === $key ? 'checked' : '' ?>>
                    <div class="p-3 rounded-xl border-2 transition-all duration-200 peer-checked:border-blue-600 peer-checked:shadow-lg hover:shadow-md">
                        <div class="w-full h-12 rounded-lg mb-2" style="background: <?= $theme['preview'] ?>"></div>
                        <p class="text-xs font-medium text-center text-gray-700"><?= htmlspecialchars($theme['name']) ?></p>
                    </div>
                </label>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- AI -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 class="text-lg font-bold text-gray-900 mb-4">
            <i class="fas fa-robot text-purple-600 mr-2"></i> AI Review Settings
        </h3>

        <div class="mb-6 flex items-center justify-between p-4 bg-gray-50 rounded-xl">
            <div>
                <label class="text-sm font-medium text-gray-700">Enable Keyword Selection</label>
                <p class="text-xs text-gray-400">Let customers select keywords before generating AI reviews</p>
            </div>
            <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" name="enable_keyword_selection" value="1" class="sr-only peer" <?= $business['enable_keyword_selection'] ? 'checked' : '' ?>>
                <div class="w-11 h-6 bg-gray-200 peer-checked:bg-blue-600 rounded-full peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
            </label>
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">Business Keywords</label>
            <input type="text" id="business_keywords" name="business_keywords"
                   value="<?= htmlspecialchars(implode(', ', $business['business_keywords'] ?? [])) ?>"
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                   placeholder="professional, quality, excellent service, friendly staff">
            <p class="text-xs text-gray-400 mt-1">Comma-separated keywords to personalize AI reviews.</p>
        </div>
    </div>

    <div class="flex justify-end">
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-xl shadow-lg transition-all transform active:scale-95">
            <i class="fas fa-save mr-2"></i> Save Settings
        </button>
    </div>
</form>

<script>
document.getElementById('logo')?.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(ev) {
        const box = document.getElementById('logoPreviewContainer');
        const placeholder = document.getElementById('logoPlaceholder');
        if (placeholder) placeholder.remove();
        let img = document.getElementById('logoPreview');
        if (!img) {
            img = document.createElement('img');
            img.id = 'logoPreview';
            img.className = 'w-full h-full object-cover';
            box.appendChild(img);
        }
        img.src = ev.target.result;
        box.classList.remove('border-dashed','border-gray-300');
        box.classList.add('border','border-gray-200');
    };
    reader.readAsDataURL(file);
});

function refreshAiPreview() {
    const kws = (document.getElementById('business_keywords')?.value || '').split(',').map(s => s.trim()).filter(Boolean).slice(0,3);
    const name = document.querySelector('input[name="name"]')?.value || 'Your Business';
    const preview = document.getElementById('aiPreview');
    if (!preview) return;
    preview.textContent = kws.length
        ? `I had an amazing experience at ${name}! The ${kws.join(', ')} were outstanding. Highly recommend!`
        : `I had an amazing experience at ${name}! The quality and service were outstanding. Highly recommend!`;
}

document.getElementById('business_keywords')?.addEventListener('input', refreshAiPreview);
document.querySelector('input[name="name"]')?.addEventListener('input', refreshAiPreview);
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/includes/card_layout.php';