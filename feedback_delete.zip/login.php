<?php
/**
 * login.php — Sign in
 * Owners → owner.php
 * Regular users → list.php (or ?redirect= target)
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

/* Already logged in? Send them to the right place */
if (isLoggedIn()) {
    header('Location: ' . (isOwner() ? 'owner.php' : 'list.php'));
    exit;
}

$errors   = [];
$redirect = $_GET['redirect'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $errors[] = 'Please enter your email and password.';
    } else {
        $stmt = $conn->prepare("SELECT id, email, password FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            loginUser((int)$user['id'], $user['email']);

            /* Owner → owner panel */
            if (isOwnerEmail($user['email'])) {
                header('Location: owner.php');
                exit;
            }

            /* Honor safe ?redirect= (same-site only) */
            if ($redirect !== '' && strpos($redirect, '://') === false) {
                header('Location: ' . $redirect);
                exit;
            }

            /* Regular users land on their cards list */
            header('Location: list.php');
            exit;
        }

        $errors[] = 'Invalid email or password.';
    }
}

$appName = getSetting('app_name', 'ReviewAI');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — <?= htmlspecialchars($appName) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center p-4">
<div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
    <div class="text-center mb-8">
        <div class="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-star text-3xl text-purple-600"></i>
        </div>
        <h1 class="text-2xl font-bold text-gray-900">Welcome back</h1>
        <p class="text-gray-500 text-sm mt-1">Sign in to <?= htmlspecialchars($appName) ?></p>
    </div>

    <?php if ($errors): ?>
        <div class="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
            <?php foreach ($errors as $e): ?>
                <p class="text-red-700 text-sm"><i class="fas fa-exclamation-circle mr-1"></i> <?= htmlspecialchars($e) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
        <div>
            <label class="text-xs font-medium text-gray-700 block mb-1">Email</label>
            <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
        </div>
        <div>
            <div class="flex justify-between items-center mb-1">
                <label class="text-xs font-medium text-gray-700">Password</label>
                <a href="forgot-password.php" class="text-xs text-purple-600 hover:underline">Forgot?</a>
            </div>
            <input type="password" name="password" required
                class="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
        </div>
        <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl transition">
            Sign In <i class="fas fa-sign-in-alt ml-2"></i>
        </button>
    </form>

    <p class="text-center text-sm text-gray-500 mt-6">
        Don't have an account?
        <a href="signup.php" class="text-purple-600 font-medium hover:underline">Sign up</a>
    </p>
</div>
</body>
</html>