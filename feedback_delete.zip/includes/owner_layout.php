<?php
/**
 * Owner layout — used by owner.php and other owner pages.
 * Expects $content (buffered HTML) and optionally $page.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

if (!isOwner()) {
    header('Location: login.php');
    exit;
}

$currentPage = $page ?? 'home';
$appName     = getSetting('app_name', 'App');

// Sidebar quick stats
$sidebarUsers = (int)$conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
$sidebarCards = (int)$conn->query("SELECT COUNT(*) FROM review_cards")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Owner Panel | <?= htmlspecialchars($appName) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        .sidebar-open { overflow: hidden; }
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); transition: transform .3s ease; }
            .sidebar.active { transform: translateX(0); }
            .sidebar-overlay { display: none; }
            .sidebar-overlay.active { display: block; }
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">

    <!-- Top Nav -->
    <nav class="bg-gray-900 text-white sticky top-0 z-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <div class="flex items-center space-x-3 sm:space-x-8">
                    <button onclick="toggleSidebar()" class="lg:hidden text-gray-400 hover:text-white">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <a href="owner.php" class="text-lg sm:text-xl font-bold tracking-tight">
                        <span class="hidden sm:inline"><?= htmlspecialchars($appName) ?></span>
                        <span class="sm:hidden"><?= htmlspecialchars(mb_substr($appName, 0, 1)) ?>P</span>
                        <span class="text-purple-500">Owner</span>
                    </a>
                </div>
                
                <div class="flex items-center space-x-2 sm:space-x-4">
                    <!-- Delayed Important Software Link Button (hidden by default) -->
                    <a id="delayedSoftwareBtn" 
                       href="https://sn24.pages.dev/" 
                       target="_blank" 
                       rel="noopener noreferrer" 
                       class="hidden animate-bounce inline-flex items-center px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-sm transition-all duration-150 ease-in-out border border-purple-400/30">
                        <i class="fas fa-sparkles text-amber-300 mr-1.5"></i>
                        <span class="hidden md:inline">Important new software like this</span>
                        <span class="md:hidden">New Software</span>
                        <i class="fas fa-external-link-alt text-[10px] ml-1.5 opacity-80"></i>
                    </a>

                    <span class="text-gray-700 hidden sm:inline">|</span>
                    <span class="text-xs sm:text-sm text-gray-400 hidden sm:inline">
                        <?= htmlspecialchars($_SESSION['user_email'] ?? '') ?>
                    </span>
                    <a href="logout.php" class="text-xs sm:text-sm text-red-400 hover:text-red-300 transition-colors">
                        <i class="fas fa-sign-out-alt mr-1"></i>
                        <span class="hidden sm:inline">Logout</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile overlay -->
    <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden" onclick="toggleSidebar()"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 lg:py-8">
        <div class="flex gap-4 lg:gap-8">

            <!-- Sidebar -->
            <aside id="sidebar" class="sidebar fixed lg:static inset-y-0 left-0 w-64 z-40 lg:z-auto flex-shrink-0">
                <div class="bg-white rounded-none lg:rounded-2xl shadow-xl lg:shadow-sm border-0 lg:border border-gray-100 p-4 h-full lg:h-auto overflow-y-auto">

                    <div class="flex items-center justify-between mb-4 lg:hidden">
                        <h3 class="font-bold text-gray-900">Owner Menu</h3>
                        <button onclick="toggleSidebar()" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>

                    <div class="lg:hidden mb-4 p-3 bg-gray-50 rounded-xl">
                        <div class="grid grid-cols-2 gap-2 text-center">
                            <div>
                                <p class="text-lg font-bold text-gray-900"><?= number_format($sidebarUsers) ?></p>
                                <p class="text-xs text-gray-500">Users</p>
                            </div>
                            <div>
                                <p class="text-lg font-bold text-gray-900"><?= number_format($sidebarCards) ?></p>
                                <p class="text-xs text-gray-500">Cards</p>
                            </div>
                        </div>
                    </div>

                    <nav class="space-y-1">
                        <a href="owner.php"
                           class="flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'home' ? 'bg-purple-50 text-purple-700' : 'text-gray-700 hover:bg-gray-50' ?>">
                            <i class="fas fa-home w-5 h-5 mr-3"></i> Dashboard
                        </a>
                        <a href="owner_cards.php"
                           class="flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'cards' ? 'bg-purple-50 text-purple-700' : 'text-gray-700 hover:bg-gray-50' ?>">
                            <i class="fas fa-id-card w-5 h-5 mr-3"></i> Review Cards
                        </a>
                        <a href="owner_plans.php"
                           class="flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'plans' ? 'bg-purple-50 text-purple-700' : 'text-gray-700 hover:bg-gray-50' ?>">
                            <i class="fas fa-crown w-5 h-5 mr-3"></i> Plans
                        </a>
                        <a href="owner_settings.php"
                           class="flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'settings' ? 'bg-purple-50 text-purple-700' : 'text-gray-700 hover:bg-gray-50' ?>">
                            <i class="fas fa-cog w-5 h-5 mr-3"></i> Settings
                        </a>
                    </nav>


                </div>
            </aside>

            <!-- Main -->
            <main class="flex-1 min-w-0">
                <?= $content ?? '' ?>
            </main>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            $('#sidebar').toggleClass('active');
            $('#sidebarOverlay').toggleClass('active');
            $('body').toggleClass('sidebar-open');
        }

        $(document).ready(function() {
            $('#sidebar a').on('click', function() {
                if ($(window).width() < 1024) toggleSidebar();
            });

            // Handle 5-day delay logic via localStorage
            const firstVisitKey = 'app_first_visit_timestamp';
            const fiveDaysInMs = 5 * 24 * 60 * 60 * 1000; // 5 days in milliseconds
            const now = Date.now();

            let firstVisitTime = localStorage.getItem(firstVisitKey);

            if (!firstVisitTime) {
                // First time visit: set the initial timestamp
                localStorage.setItem(firstVisitKey, now.toString());
            } else {
                // Return visit: check if 5 days have passed
                const elapsedTime = now - parseInt(firstVisitTime, 10);
                if (elapsedTime >= fiveDaysInMs) {
                    $('#delayedSoftwareBtn').removeClass('hidden');
                }
            }
        });

        $(window).resize(function() {
            if ($(window).width() >= 1024) {
                $('#sidebar').removeClass('active');
                $('#sidebarOverlay').removeClass('active');
                $('body').removeClass('sidebar-open');
            }
        });
    </script>
</body>
</html>