<?php
/**
 * Core helper functions — settings, URL, keywords, AI review generation.
 */

require_once __DIR__ . '/db.php';

/* =========================================================
   SETTINGS (key/value in `settings` table, with in-memory cache)
   ========================================================= */

function getSetting($key, $default = null) {
    static $cache = [];

    if (array_key_exists($key, $cache)) {
        return $cache[$key] === null ? $default : $cache[$key];
    }

    global $conn;
    try {
        $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
        $stmt->execute([$key]);
        $val = $stmt->fetchColumn();
        $cache[$key] = ($val === false) ? null : $val;
    } catch (Exception $e) {
        $cache[$key] = null;
    }

    return $cache[$key] === null ? $default : $cache[$key];
}

function setSetting($key, $value) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    $stmt->execute([$key, (string)$value]);
    return true;
}

function getAllSettings() {
    global $conn;
    $rows = $conn->query("SELECT setting_key, setting_value FROM settings")->fetchAll();
    $out = [];
    foreach ($rows as $r) $out[$r['setting_key']] = $r['setting_value'];
    return $out;
}

/* =========================================================
   OWNER / ADMIN HELPERS
   ========================================================= */

function isOwnerEmail($email) {
    $owner = getSetting('owner_email', '');
    if ($owner === '' || $email === '') return false;
    return strcasecmp(trim($email), trim($owner)) === 0;
}

/* =========================================================
   URL / ASSET HELPERS
   ========================================================= */

function baseUrl() {
    $url = getSetting('site_url', '');
    if ($url === '') {
        $cfg = getConfig();
        $url = $cfg['site_url'] ?? '';
    }
    return rtrim($url, '/');
}

/**
 * url('login.php')   → https://site.com/login.php
 * url('/')           → https://site.com
 * url('assets/x.png')→ https://site.com/assets/x.png
 */
function url($path = '') {
    $base = baseUrl();
    $path = (string)$path;

    if (preg_match('#^https?://#i', $path)) return $path;

    if ($path === '' || $path === '/') return $base;

    return $base . '/' . ltrim($path, '/');
}

function asset($path) {
    return url('assets/' . ltrim($path, '/'));
}

function redirect($path) {
    header('Location: ' . (preg_match('#^https?://#i', $path) ? $path : url($path)));
    exit;
}

/* =========================================================
   STRING / SLUG HELPERS
   ========================================================= */

function slugify($text) {
    $text = strtolower(trim((string)$text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    $text = trim($text, '-');
    return $text === '' ? 'card' : $text;
}

function uniqueCardSlug($name, $excludeId = null) {
    global $conn;
    $base = slugify($name);
    $slug = $base;
    $i = 2;

    while (true) {
        if ($excludeId) {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM review_cards WHERE slug = ? AND id != ?");
            $stmt->execute([$slug, $excludeId]);
        } else {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM review_cards WHERE slug = ?");
            $stmt->execute([$slug]);
        }
        if ((int)$stmt->fetchColumn() === 0) return $slug;
        $slug = $base . '-' . $i++;
        if ($i > 1000) return $base . '-' . time();
    }
}

function e($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/* =========================================================
   KEYWORDS
   ========================================================= */

function getKeywords() {
    global $conn;
    try {
        $rows = $conn->query("SELECT keyword FROM keywords ORDER BY sort_order ASC, id ASC")->fetchAll();
        return array_column($rows, 'keyword');
    } catch (Exception $e) {
        return [];
    }
}

function saveKeywords(array $keywords) {
    global $conn;
    $conn->exec("DELETE FROM keywords");
    $stmt = $conn->prepare("INSERT INTO keywords (keyword, sort_order) VALUES (?, ?)");
    $i = 0;
    foreach ($keywords as $kw) {
        $kw = trim((string)$kw);
        if ($kw === '') continue;
        $stmt->execute([$kw, $i++]);
    }
}

/* =========================================================
   AI REVIEW GENERATION (GROQ)
   ========================================================= */

/**
 * Calls Groq's chat completion endpoint to generate review texts.
 * Returns an array of strings. On failure returns [] and logs last error.
 */
function callGroq($prompt, $maxTokens = 800, $temperature = 0.8) {
    $apiKey = getSetting('groq_api_key', '');
    if ($apiKey === '') {
        $GLOBALS['groq_last_error'] = 'GROQ API key is not configured.';
        return null;
    }

    $model = getSetting('groq_model', 'llama-3.3-70b-versatile');

    $payload = [
        'model'       => $model,
        'messages'    => [
            ['role' => 'system', 'content' => 'You are a helpful assistant that writes authentic-sounding customer reviews. Return ONLY valid JSON, no markdown fences, no extra text.'],
            ['role' => 'user',   'content' => $prompt],
        ],
        'temperature' => $temperature,
        'max_tokens'  => $maxTokens,
    ];

    $ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
        ],
        CURLOPT_TIMEOUT        => 30,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($response === false || $curlErr) {
        $GLOBALS['groq_last_error'] = 'cURL error: ' . $curlErr;
        return null;
    }

    $data = json_decode($response, true);

    if ($httpCode >= 400) {
        $msg = $data['error']['message'] ?? ('HTTP ' . $httpCode);
        $GLOBALS['groq_last_error'] = 'Groq error: ' . $msg;
        return null;
    }

    $content = $data['choices'][0]['message']['content'] ?? '';
    if ($content === '') {
        $GLOBALS['groq_last_error'] = 'Empty response from Groq.';
        return null;
    }

    // Strip any stray markdown fences
    $content = preg_replace('/^```(?:json)?|```$/m', '', trim($content));

    $parsed = json_decode($content, true);
    if (!is_array($parsed)) {
        $GLOBALS['groq_last_error'] = 'Could not parse Groq JSON output.';
        return null;
    }

    return $parsed;
}

/**
 * Generate review strings for a business given keywords.
 * Returns array of plain-text review bodies.
 */
function generateAIReviews($businessName, array $keywords = [], $count = 5) {
    $businessName = trim((string)$businessName) ?: 'this business';
    $keywords = array_values(array_filter(array_map('trim', $keywords)));

    $kwText = $keywords ? implode(', ', $keywords) : 'quality, service, experience';

    $prompt = "Write {$count} unique, natural-sounding, positive customer reviews for a business called \"{$businessName}\".\n"
            . "Each review must:\n"
            . "- be 1-3 sentences (25-60 words)\n"
            . "- sound like a real customer (vary tone, add small specifics)\n"
            . "- naturally include 1-2 of these keywords: {$kwText}\n"
            . "- be written in first person (\"I\", \"we\")\n"
            . "- avoid repeating sentence openers across reviews\n"
            . "- NOT include star ratings or emojis\n\n"
            . "Return strict JSON in this exact shape: {\"reviews\":[\"…\",\"…\"]}";

    $result = callGroq($prompt, 900, 0.85);

    if (!is_array($result) || empty($result['reviews']) || !is_array($result['reviews'])) {
        return [];
    }

    $out = [];
    foreach ($result['reviews'] as $r) {
        if (is_string($r) && trim($r) !== '') {
            $out[] = trim($r);
        }
    }
    return $out;
}

/* =========================================================
   REVIEW CARDS
   ========================================================= */

function getCardBySlug($slug) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM review_cards WHERE slug = ? LIMIT 1");
    $stmt->execute([$slug]);
    return $stmt->fetch() ?: null;
}

function getCardById($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM review_cards WHERE id = ? LIMIT 1");
    $stmt->execute([(int)$id]);
    return $stmt->fetch() ?: null;
}

function getCardsByUser($userId) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM review_cards WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([(int)$userId]);
    return $stmt->fetchAll();
}

function decodeDetails($card) {
    if (empty($card['details'])) return [];
    $d = json_decode($card['details'], true);
    return is_array($d) ? $d : [];
}

/* =========================================================
   ANALYTICS HELPERS
   ========================================================= */

function getCardStats($cardId) {
    global $conn;
    $stmt = $conn->prepare("SELECT COUNT(*) AS total, AVG(rating) AS avg_rating
        FROM reviews WHERE card_id = ?");
    $stmt->execute([(int)$cardId]);
    $row = $stmt->fetch() ?: ['total' => 0, 'avg_rating' => 0];

    $stmt = $conn->prepare("SELECT COUNT(*) FROM feedbacks WHERE card_id = ? AND status = 'new'");
    $stmt->execute([(int)$cardId]);
    $newFeedback = (int)$stmt->fetchColumn();

    return [
        'total_reviews'   => (int)$row['total'],
        'avg_rating'      => round((float)$row['avg_rating'], 2),
        'new_feedbacks'   => $newFeedback,
    ];
}

function getRatingBreakdown($cardId) {
    global $conn;
    $stmt = $conn->prepare("SELECT rating, COUNT(*) AS c FROM reviews WHERE card_id = ? GROUP BY rating");
    $stmt->execute([(int)$cardId]);
    $out = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
    foreach ($stmt->fetchAll() as $row) {
        $out[(int)$row['rating']] = (int)$row['c'];
    }
    return $out;
}

/* =========================================================
   MISC
   ========================================================= */

function timeAgo($datetime) {
    $diff = time() - strtotime($datetime);
    if ($diff < 60)     return 'just now';
    if ($diff < 3600)   return floor($diff / 60) . 'm ago';
    if ($diff < 86400)  return floor($diff / 3600) . 'h ago';
    if ($diff < 604800) return floor($diff / 86400) . 'd ago';
    return date('M j, Y', strtotime($datetime));
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

