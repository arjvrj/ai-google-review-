<?php
/**
 * Card panel layout — used by card_home.php, card_reviews.php, card_settings.php, card_membership.php
 * Expects: $content (buffered HTML), $card (the review_cards row), optional $page
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
$slug   = trim($_GET['slug'] ?? '');

$stmt = $conn->prepare("SELECT * FROM review_cards WHERE slug = ? AND user_id = ? LIMIT 1");
$stmt->execute([$slug, $userId]);
$card = $stmt->fetch();

if (!$card) {
    header('Location: list.php');
    exit;
}

$currentPage = $page ?? 'home';
$appName     = getSetting('app_name', 'App');

$mcls = $card['membership'] === 'trial'
    ? 'bg-yellow-100 text-yellow-800'
    : ($card['membership'] === 'pro' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($card['name']) ?> - Panel | <?= htmlspecialchars($appName) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .sidebar-open { overflow: hidden; }
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); transition: transform .3s ease; }
            .sidebar.active { transform: translateX(0); }
            .sidebar-overlay { display: none; }
            .sidebar-overlay.active { display: block; }
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">

    <!-- Top Nav -->
    <nav class="bg-white border-b border-gray-200 sticky top-0 z-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16 items-center">
                <div class="flex items-center min-w-0">
                    <button onclick="toggleSidebar()" class="lg:hidden text-gray-500 hover:text-gray-700 mr-3">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <a href="list.php" class="text-gray-400 hover:text-gray-600 mr-2 sm:mr-4" title="Back to my cards">
                        <svg class="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                        </svg>
                    </a>
                    <div class="min-w-0">
                        <h1 class="text-base sm:text-xl font-bold text-gray-900 truncate max-w-[140px] sm:max-w-[280px]">
                            <?= htmlspecialchars($card['name']) ?>
                        </h1>
                    </div>
                    <span class="hidden sm:inline ml-3 px-2 py-1 text-xs font-medium rounded-full <?= $mcls ?>">
                        <?= htmlspecialchars(ucfirst($card['membership'])) ?>
                    </span>
                </div>

                <div class="flex items-center space-x-2 sm:space-x-4">
                    <!-- View public page -->
                    <a href="review.php?slug=<?= urlencode($card['slug']) ?>" target="_blank"
                       class="text-xs sm:text-sm text-blue-600 hover:text-blue-800 font-medium">
                        <i class="fas fa-external-link-alt mr-1"></i>
                        <span class="hidden sm:inline">View Page</span>
                    </a>

                    <!-- Divider (desktop only) -->
                    <span class="hidden sm:inline text-gray-300">|</span>

                    <!-- User email (desktop only) -->
                    <span class="hidden md:inline text-xs text-gray-500 truncate max-w-[180px]">
                        <?= htmlspecialchars($_SESSION['user_email'] ?? '') ?>
                    </span>

                    <!-- Logout -->
                    <a href="logout.php"
                       class="inline-flex items-center text-xs sm:text-sm text-red-600 hover:text-red-800 font-medium px-2 py-1.5 rounded-lg hover:bg-red-50 transition-colors">
                        <i class="fas fa-sign-out-alt sm:mr-1"></i>
                        <span class="hidden sm:inline">Logout</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile overlay -->
    <div id="sidebarOverlay" class="sidebar-overlay fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden" onclick="toggleSidebar()"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 lg:py-8">
        <div class="flex gap-4 lg:gap-8">

            <!-- Sidebar -->
            <aside id="sidebar" class="sidebar fixed lg:static inset-y-0 left-0 w-64 bg-white lg:bg-transparent z-40 lg:z-auto shadow-xl lg:shadow-none flex-shrink-0 overflow-y-auto lg:overflow-visible">
                <div class="p-4 lg:p-0 flex flex-col h-full">
                    <div class="flex items-center justify-between mb-4 lg:hidden">
                        <h3 class="font-bold text-gray-900">Menu</h3>
                        <button onclick="toggleSidebar()" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>

                    <?php $s = urlencode($card['slug']); ?>
                    <nav class="space-y-1">
                        <a href="card_home.php?slug=<?= $s ?>"
                           class="flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'home' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100' ?>">
                            <i class="fas fa-home w-5 h-5 mr-3"></i> Home
                        </a>
                        <a href="card_membership.php?slug=<?= $s ?>"
                           class="flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'membership' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100' ?>">
                            <i class="fas fa-crown w-5 h-5 mr-3"></i> Membership
                        </a>
                        <a href="card_reviews.php?slug=<?= $s ?>&filter=reviews"
                           class="flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'reviews' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100' ?>">
                            <i class="fas fa-star w-5 h-5 mr-3"></i> Reviews
                        </a>
                        <a href="card_settings.php?slug=<?= $s ?>"
                           class="flex items-center px-4 py-3 text-sm font-medium rounded-lg <?= $currentPage === 'settings' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100' ?>">
                            <i class="fas fa-cog w-5 h-5 mr-3"></i> Settings
                        </a>
                    </nav>

                    <!-- Mobile-only: user info + logout at bottom of sidebar -->
                    <div class="mt-auto pt-6 border-t border-gray-200 lg:hidden">
                        <div class="flex items-center gap-3 px-2 mb-3">
                            <div class="w-9 h-9 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                                <i class="fas fa-user text-blue-600 text-sm"></i>
                            </div>
                            <div class="min-w-0">
                                <p class="text-xs text-gray-500">Signed in as</p>
                                <p class="text-sm font-medium text-gray-900 truncate">
                                    <?= htmlspecialchars($_SESSION['user_email'] ?? '') ?>
                                </p>
                            </div>
                        </div>
                        <a href="logout.php"
                           class="flex items-center px-4 py-3 text-sm font-medium rounded-lg text-red-600 hover:bg-red-50 transition-colors">
                            <i class="fas fa-sign-out-alt w-5 h-5 mr-3"></i> Logout
                        </a>
                    </div>
                </div>
            </aside>

            <!-- Main content -->
            <main class="flex-1 min-w-0">
                <?= $content ?? '' ?>
            </main>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            $('#sidebar').toggleClass('active');
            $('#sidebarOverlay').toggleClass('active');
            $('body').toggleClass('sidebar-open');
        }
        $(document).ready(function() {
            $('#sidebar a').on('click', function() {
                if ($(window).width() < 1024) toggleSidebar();
            });
        });
        $(window).resize(function() {
            if ($(window).width() >= 1024) {
                $('#sidebar').removeClass('active');
                $('#sidebarOverlay').removeClass('active');
                $('body').removeClass('sidebar-open');
            }
        });
    </script>
</body>
</html>