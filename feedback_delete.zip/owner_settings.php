<?php
/**
 * owner_settings.php — Owner panel: platform-wide settings
 * URL:   owner_settings.php
 * POST:  owner_settings.php?action=save
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireOwner();

/* =========================================================
   AJAX DISPATCHER
   ========================================================= */
$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'save') {
    header('Content-Type: application/json');

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }

    $whatsapp = trim($_POST['whatsapp'] ?? '');

    if ($whatsapp === '') {
        echo json_encode(['error' => 'WhatsApp number is required']);
        exit;
    }

    try {
        /* ---------- Platform WhatsApp (single-row table) ---------- */
        $stmt = $conn->query("SELECT COUNT(*) FROM platform_settings");
        $exists = (int)$stmt->fetchColumn() > 0;

        if ($exists) {
            $stmt = $conn->prepare("UPDATE platform_settings SET whatsapp = ? LIMIT 1");
            $stmt->execute([$whatsapp]);
        } else {
            $stmt = $conn->prepare("INSERT INTO platform_settings (whatsapp) VALUES (?)");
            $stmt->execute([$whatsapp]);
        }

        /* ---------- Optional: App Name + GROQ key (settings table) ---------- */
        if (isset($_POST['app_name'])) {
            $appName = trim((string)$_POST['app_name']);
            if ($appName !== '') setSetting('app_name', $appName);
        }

        if (isset($_POST['groq_api_key'])) {
            $groqKey = trim((string)$_POST['groq_api_key']);
            setSetting('groq_api_key', $groqKey);
        }

        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['error' => 'Could not save settings']);
    }
    exit;
}

/* =========================================================
   RENDER
   ========================================================= */

$page = 'settings';

$settings = $conn->query("SELECT * FROM platform_settings LIMIT 1")->fetch();
if (!$settings) {
    $settings = ['whatsapp' => '', 'details' => '{}'];
}
$platformWhatsapp = $settings['whatsapp'] ?? '';

$appName        = getSetting('app_name', 'ReviewAI');
$currentGroqKey = getSetting('groq_api_key', '');

ob_start();
?>

<div class="mb-6">
    <h2 class="text-2xl font-bold text-gray-900">Platform Settings</h2>
    <p class="text-gray-500 mt-1">Configure your platform's global settings</p>
</div>

<form id="settingsForm" onsubmit="saveSettings(event)" class="space-y-6">

    <!-- WhatsApp -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div class="flex items-center mb-4">
            <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center mr-3">
                <i class="fab fa-whatsapp text-green-600 text-xl"></i>
            </div>
            <div>
                <h3 class="text-lg font-bold text-gray-900">WhatsApp Payment Settings</h3>
                <p class="text-sm text-gray-500">Where you'll receive payment notifications</p>
            </div>
        </div>

        <div class="max-w-2xl">
            <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-4">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <i class="fas fa-info-circle text-yellow-600 text-lg"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-yellow-700">
                            <strong>Important:</strong> This WhatsApp number receives all payment notifications and upgrade requests from your platform. Make sure this number is active on WhatsApp.
                        </p>
                    </div>
                </div>
            </div>

            <label class="block text-sm font-medium text-gray-700 mb-2">
                WhatsApp Number for Payments *
            </label>
            <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i class="fab fa-whatsapp text-green-500 text-lg"></i>
                </div>
                <input type="text" name="whatsapp" required
                       value="<?= htmlspecialchars($platformWhatsapp) ?>"
                       class="w-full pl-12 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent text-lg"
                       placeholder="+91 9876543210">
            </div>
            <p class="text-xs text-gray-500 mt-2">
                Enter the WhatsApp number with country code where you want to receive payment confirmations.
            </p>
        </div>
    </div>

    <!-- App Name -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div class="flex items-center mb-4">
            <div class="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center mr-3">
                <i class="fas fa-tag text-purple-600"></i>
            </div>
            <div>
                <h3 class="text-lg font-bold text-gray-900">App Branding</h3>
                <p class="text-sm text-gray-500">Name shown across the platform</p>
            </div>
        </div>

        <div class="max-w-2xl">
            <label class="block text-sm font-medium text-gray-700 mb-2">App Name</label>
            <input type="text" name="app_name"
                   value="<?= htmlspecialchars($appName) ?>"
                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                   placeholder="ReviewAI">
            <p class="text-xs text-gray-500 mt-2">Displayed in the navbar, page titles, and emails.</p>
        </div>
    </div>

    <!-- GROQ API Key -->
    <div class="bg-white rounded-2xl shadow-sm border-2 border-yellow-200 p-6">
        <div class="flex items-center mb-4">
            <div class="w-10 h-10 bg-yellow-100 rounded-xl flex items-center justify-center mr-3">
                <i class="fas fa-key text-yellow-600"></i>
            </div>
            <div>
                <h3 class="text-lg font-bold text-gray-900">GROQ API Configuration</h3>
                <p class="text-sm text-gray-500">Powers AI review generation platform-wide</p>
            </div>
        </div>

        <div class="max-w-2xl">
            <label class="block text-sm font-medium text-gray-700 mb-2">GROQ API Key</label>
            <div class="relative">
                <input type="password" id="groq_api_key" name="groq_api_key"
                       value="<?= htmlspecialchars($currentGroqKey) ?>"
                       class="w-full px-4 py-3 pr-12 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent font-mono text-sm"
                       placeholder="gsk_..."
                       autocomplete="off">
                <button type="button" onclick="toggleGroqVisibility()"
                        class="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-gray-400 hover:text-gray-700">
                    <i class="fas fa-eye" id="groqEyeIcon"></i>
                </button>
            </div>
            <p class="text-xs text-gray-500 mt-2">
                Get your key from
                <a href="https://console.groq.com/keys" target="_blank" class="text-yellow-700 underline">console.groq.com/keys</a>.
                Leave blank to disable AI generation.
            </p>

            <?php if ($currentGroqKey !== ''): ?>
                <div class="mt-3 flex items-center gap-2 text-xs text-green-700 bg-green-50 border border-green-200 rounded-lg p-2.5">
                    <i class="fas fa-check-circle"></i>
                    <span>GROQ key is configured. AI review generation is active.</span>
                </div>
            <?php else: ?>
                <div class="mt-3 flex items-center gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-2.5">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>No GROQ key configured — AI review generation is currently disabled.</span>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Save -->
    <div class="flex justify-end">
        <button type="submit"
                class="px-8 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors font-medium shadow-lg flex items-center">
            <i class="fas fa-save mr-2"></i> Save Settings
        </button>
    </div>
</form>

<!-- Toast container -->
<div id="toast" class="fixed top-4 right-4 bg-gray-900 text-white px-6 py-3 rounded-xl shadow-2xl z-50 hidden flex items-center gap-3">
    <i class="fas fa-check-circle text-green-400"></i>
    <span id="toastMessage">Saved!</span>
</div>

<script>
function saveSettings(e) {
    e.preventDefault();

    const whatsapp = $('input[name="whatsapp"]').val().trim();
    if (!whatsapp) { alert('Please enter a WhatsApp number'); return; }

    const submitBtn = $(e.target).find('button[type="submit"]');
    const originalHtml = submitBtn.html();

    submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin mr-2"></i> Saving...');

    $.ajax({
        url: 'owner_settings.php?action=save',
        method: 'POST',
        data: {
            whatsapp:     whatsapp,
            app_name:     $('input[name="app_name"]').val().trim(),
            groq_api_key: $('#groq_api_key').val()
        },
        dataType: 'json',
        success: function(res) {
            submitBtn.prop('disabled', false).html(originalHtml);
            if (res.success) {
                showToast('Settings saved successfully!');
            } else {
                alert('Error: ' + (res.error || 'Unknown error'));
            }
        },
        error: function() {
            submitBtn.prop('disabled', false).html(originalHtml);
            alert('Error saving settings. Please try again.');
        }
    });
}

function showToast(msg) {
    $('#toastMessage').text(msg);
    $('#toast').removeClass('hidden').fadeIn(200);
    setTimeout(() => $('#toast').fadeOut(200), 2500);
}

function toggleGroqVisibility() {
    const input = document.getElementById('groq_api_key');
    const icon  = document.getElementById('groqEyeIcon');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
}
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/includes/owner_layout.php';